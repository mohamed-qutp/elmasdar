

<?php $__env->startSection('title', 'تفاصيل القسم'); ?>
<?php $__env->startSection('t2','/الأقسام'); ?>
<?php $__env->startSection('t3','/تفاصيل القسم'); ?>
<?php $__env->startSection('pagetitle','تفاصيل القسم'); ?>
<?php $__env->startSection('body'); ?>

<form autocomplete="off" method="post">
    <?php echo csrf_field(); ?>   
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control-plaintext" readonly value="<?php echo e($department->name); ?>" name="name" id="name" placeholder="الاسم" required>

                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="phone_number">رئيس القسم</label>
                                <?php if($department_leader !== null): ?> 
                                <input name="phone_number" value="<?php echo e($department_leader->name); ?>" class="form-control-plaintext" readonly id="phone_number" type="text" placeholder="لا يوجد" required>
                                <?php endif; ?>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="phone_number">موظفين القسم</label>
                                <ul>
                                    <?php $__currentLoopData = $department->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($user->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <!-- End of Form -->
                        </div>
                       
                        <div class="row">                            
                            <div class="col-lg-4 col-sm-6">
                                <a class="btn btn-secondary" href="<?php echo e(route('departments.edit',$department->id)); ?>" type="submit">تعديل بيانات القسم</a>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <form method="get" action="<?php echo e(route('departments.destroy',$department->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="hidden" name="_method" value="DELETE" />
                                    <a data-bs-toggle="modal" data-bs-target="#delete" class="btn btn-danger">حذف القسم</a>
                                </form>
                            </div>
                        </div>
                        <!--                                 delete                                             -->
                        <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">حذف القسم</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        هل تريد حذف القسم
                                    </div>
                                    <div class="modal-footer">
                                            <input type="hidden" name="_method" value="DELETE" />
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">الغاء</button>
                                            <button type="submit" class="btn btn-danger me-2">حذف </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sithr\resources\views/pages/departments/department_show.blade.php ENDPATH**/ ?>