<?php echo e($slot); ?>

<?php /**PATH /home3/ilcruumy/public_html/sitksa-hr/sithr/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>