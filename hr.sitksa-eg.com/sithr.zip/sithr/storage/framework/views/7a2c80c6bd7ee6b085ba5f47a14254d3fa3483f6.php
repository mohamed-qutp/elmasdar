

<?php $__env->startSection('title', 'اضافة عقد'); ?>
<?php $__env->startSection('t2','/العقود'); ?>
<?php $__env->startSection('t3','/اضافة عقد'); ?>
<?php $__env->startSection('pagetitle','اضافة عقد'); ?>
<?php $__env->startSection('body'); ?>
<form action="<?php echo e(route('contract.store')); ?>" autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="from">تاريخ بداية العقد</label>
                                <input type="date" class="form-control" value="<?php echo e(old('from')); ?>" name="from" id="from" placeholder="dd/mm/yyyy" required>
                                <small class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="to">تاريخ انتهاء العقد</label>
                                <input type="date" name="to" class="form-control" value="<?php echo e(old('to')); ?>" id="to" placeholder="dd/mm/yyyy" required>
                                <small id="emailHelp" class="form-text text-muted">* مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="users">الموظف</label>
                                <div class="input-group">
                                    <select name="users" value="<?php echo e(old('users')); ?>" class="form-control" required>
                                        <option value="" disbaled>اختر الموظف</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                                        <option value="<?php echo e($users->id); ?>"><?php echo e($users->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">* مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <button class="btn btn-secondary" name="save" type="submit">حفظ</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/contracts/contract_create.blade.php ENDPATH**/ ?>