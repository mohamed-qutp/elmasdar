

<?php $__env->startSection('title', 'قائمة الموظفين'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/عرض الموظفين'); ?>
<?php $__env->startSection('pagetitle','قائمة الموظفين'); ?>

<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/users/test.blade.php ENDPATH**/ ?>