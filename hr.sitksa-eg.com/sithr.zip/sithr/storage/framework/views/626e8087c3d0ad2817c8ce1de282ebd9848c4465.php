

<?php $__env->startSection('title', 'تعديل القسم'); ?>
<?php $__env->startSection('t2','/الأقسام'); ?>
<?php $__env->startSection('t3','/تعديل القسم'); ?>
<?php $__env->startSection('pagetitle','تعديل القسم'); ?>
<?php $__env->startSection('body'); ?>


<form action="<?php echo e(route('departments.update',$department->id)); ?>" autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control" value="<?php echo e($department->name); ?>" name="name" id="name" placeholder="الاسم" required>
                                
                            </div> 
                            <div class="mb-3">
                                <label for="exampleInputIconPassword">رئيس القسم</label>
                                <div class="input-group">
                                    <select class="form-select" name="leader_id" aria-label="Default select example">
                                        <option value="">اختر</option>
                                        <?php $__currentLoopData = $department->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($department->leader_id == $user->id): ?>
                                        <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endif; ?>                                       
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                        
                                    </select>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>                        
                        
                        <div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <button class="btn btn-secondary" name="update" type="submit">تعديل</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sithr\resources\views/pages/departments/departmentedit.blade.php ENDPATH**/ ?>