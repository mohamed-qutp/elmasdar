

<?php $__env->startSection('title', 'طلبات ملف الحضور'); ?>
<?php $__env->startSection('t2','/طلبات ملف الحضور'); ?>
<?php $__env->startSection('pagetitle','طلبات ملف الحضور'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">صاحب الطلب</th>
                        <th class="border-0">الحالة</th>
                        <th class="border-0">تفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($attendance) > 0): ?>
                    <?php echo e($attendance->links("pagination::bootstrap-4")); ?>

                        <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attendance->id); ?></td>
                        <td><?php echo e($attendance->users->name); ?></td>
                        <td>
                            <?php if($attendance->file_path == null): ?>
                                لم يتم رفع الملف بعد
                            <?php else: ?>
                                تم رفع الملف
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('att-file.show',$attendance->id)); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>لا يوجد طلبات</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/attendance/attendance-auth.blade.php ENDPATH**/ ?>