

<?php $__env->startSection('title', 'تفاصيل المهمة'); ?>
<?php $__env->startSection('t2','/المهام'); ?>
<?php $__env->startSection('t3','/تفاصيل المهمة'); ?>
<?php $__env->startSection('pagetitle','تفاصيل المهمة'); ?>
<?php $__env->startSection('body'); ?>

<form autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row">
                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="title">العنوان</label>
                            <div class="input-group">
                                <input type="text" name="title" class="form-control-plaintext" value="<?php echo e($task->title); ?>" required>
                            </div>  
                        </div>
                        <!-- End of Form -->

                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="description">التفاصيل</label>
                            <div class="input-group">
                                <textarea name="description" class="form-control-plaintext" required><?php echo e($task->description); ?></textarea>
                            </div>  
                        </div>
                        <!-- End of Form -->
                        <!-- Form -->
                        <div class="form-group col-md-2">
                            <div class="input-group">
                                <?php if($task->done == '0'): ?>
                                <div class="badge bg-warning" style="padding: 5px;font-size:1em;color:black">قيد التنفيذ</div>
                                <?php else: ?>
                                <div class="badge bg-success" style="padding: 5px;font-size:1em;color:black">تم التنفيذ</div>
                                <?php endif; ?>
                            </div>  
                        </div>
                        <!-- End of Form -->
                        <!-- Form -->
                        <form action="<?php echo e(route('task.status',$task->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group col-md-2">
                                <div class="input-group">
                                    <?php if($task->done == '0'): ?>
                                    <button class="btn btn-success">انهاء المهمة</button>
                                    <?php endif; ?>
                                </div>  
                            </div>
                        </form>
                        <!-- End of Form -->
                    </div>
                    <div class="row">
                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="assigned_to">صاحب المهمة</label>
                            <input type="text" class="form-control-plaintext" value="<?php echo e($task->userTask->name); ?>">
                        </div>
                        <!-- End of Form -->

                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="projects">مكلفة من</label>
                            <input type="text" class="form-control-plaintext" value="<?php echo e($task->users->name); ?>">
                        </div>
                        <!-- End of Form -->

                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="projects">المشروع</label></br>
                            <a href="<?php echo e(route('projects.show',$task->project_id)); ?>"><?php echo e($task->projects->name); ?></a>
                        </div>
                        <!-- End of Form -->
                    </div><hr>
                    <div class="row">
                        <label><b>وقت انجاز المهمة</b></label></br>
                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="from">من</label>
                            <div class="input-group">
                                <input type="text" class="form-control-plaintext" value="<?php echo e($task->from); ?>" name="from" required>
                            </div>  
                        </div>
                        <!-- End of Form -->
                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <label for="to">الى</label>
                            <div class="input-group">
                                <input type="text" name="to" class="form-control-plaintext" value="<?php echo e($task->to); ?>" required>
                            </div>  
                        </div>
                        <!-- End of Form -->
                        <!-- Form -->
                        <div class="form-group col-md-4">
                            <div class="input-group">
                                <a class="btn btn-pill btn-outline-primary comment_button">اضافة تعليق</a>
                            </div>  
                        </div>
                        <!-- End of Form -->
                    </div>
                    <form action="<?php echo e(route('comments.store',$task->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row" id="comment_div" style="display: none">
                            <div class="col-md-6">
                                <textarea class="form-control" name="comment" rows="5" placeholder="اضف تعليق"></textarea>
                            </div>
                            <div class="col-md-6">
                                <button class="btn btn-pill btn-outline-secondary">ارسال</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-12 mb-4">
            <div class="card border-0 shadow">
                <div class="card-header border-bottom d-flex align-items-center justify-content-between">
                    <h2 class="fs-5 fw-bold mb-0">التعليقات</h2>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush list my--3">
                        <?php if(count($comments) > 0): ?>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item px-0">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <!-- Avatar -->
                                    <a href="<?php echo e(route('users.show',$comments->user_id)); ?>" class="avatar">
                                    <?php if($comments->users->gender == "male"): ?>
                                        <img class="rounded" alt="Image placeholder" src="<?php echo e(asset('assets/img/team/male.png')); ?>">
                                    <?php else: ?>
                                        <img class="rounded" alt="Image placeholder" src="<?php echo e(asset('assets/img/team/female.png')); ?>">
                                    <?php endif; ?>
                                    </a>
                                </div>
                                <div class="col-auto ms--2">
                                    <h4 class="h6 mb-0">
                                        <a href="<?php echo e(route('users.show',$comments->user_id)); ?>" style="color: #3C5FC5"><?php echo e($comments->users->name); ?></a>
                                    </h4>
                                    <div class="d-flex align-items-center">
                                        <small><?php echo e($comments->comment); ?></small>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <form action="<?php echo e(route('comments.delete',$comments->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <p><?php echo e($comments->created_at); ?></p>
                            </div>
                            <?php if(Auth::user()->id == $comments->user_id): ?>
                                <div class="col-md-6">
                                    <button class="btn btn-sm btn-outline-danger" style="float: left"><i class="fa fa-trash"></i></button>
                                </div>
                            <?php endif; ?>
                        </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            لا يوجد تعليقات
                        <?php endif; ?>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/tasks/user_tasks_show.blade.php ENDPATH**/ ?>