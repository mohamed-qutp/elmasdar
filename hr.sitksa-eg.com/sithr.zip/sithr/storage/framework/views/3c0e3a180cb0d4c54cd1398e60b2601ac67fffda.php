

<?php $__env->startSection('title', 'تفاصيل المشروع'); ?>
<?php $__env->startSection('t2','/المشاريع'); ?>
<?php $__env->startSection('t3','/تفاصيل المشروع'); ?>
<?php $__env->startSection('pagetitle','تفاصيل المشروع'); ?>
<?php $__env->startSection('body'); ?>

<form autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control-plaintext" readonly value="<?php echo e($project->name); ?>" name="name" id="name" placeholder="الاسم" required>

                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="client">العميل</label>
                                <input name="client" value="<?php echo e($project->client->name); ?>" class="form-control-plaintext" readonly id="client" type="text" placeholder="لا يوجد" required>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <a class="btn btn-secondary" href="<?php echo e(route('projects.edit',$project->id)); ?>" type="submit">تعديل بيانات المشروع</a>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <form method="post" action="<?php echo e(route('projects.destroy',$project->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <td><a data-bs-toggle="modal" data-bs-target="#delete" class="btn btn-danger"><i class="fa-solid fa-xmark"></i></a></td>
                                </form>
                            </div>
                        </div>
                        <!-------------------------------------------------delete -------------------------------------------->
                        <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">حذف المشروع</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <div class="modal-body">
                                        هل تريد حذف المشروع </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="_method" value="DELETE" />
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">الغاء</button>
                                        <button type="submit" class="btn btn-danger me-2">حذف </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/projects/project_show.blade.php ENDPATH**/ ?>