
<nav class="navbar navbar-dark navbar-theme-primary px-4 col-12 d-lg-none">
    <a class="navbar-brand me-lg-5" href="<?php echo e(route('index')); ?>">
        <img class="navbar-brand-dark" src="<?php echo e(asset('assets/img/favicon/logo-2.png')); ?>" alt="Volt logo" /> <img class="navbar-brand-light" src="<?php echo e(asset('assets/img/favicon/logo-2.png')); ?>" alt="Volt logo" />
    </a>
    <div class="d-flex align-items-center">
        <button class="navbar-toggler d-lg-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse print-container" data-simplebar>
  <div class="sidebar-inner px-4 pt-3">
    <div class="user-card d-flex d-md-none align-items-center justify-content-between justify-content-md-center pb-4">
      <div class="d-flex align-items-center">
        <div class="avatar-lg me-4">
          <?php if(Auth::user()->gender == "male"): ?>
          <img src="<?php echo e(asset('assets/img/team/male.png')); ?>" class="card-img-top rounded-circle border-white" alt="<?php echo e(Auth::user()->name); ?>">
          <?php else: ?>
          <img src="<?php echo e(asset('assets/img/team/female.png')); ?>" class="card-img-top rounded-circle border-white" alt="<?php echo e(Auth::user()->name); ?>">
          <?php endif; ?>
        </div>
        <form action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="d-block">
          <h2 class="h5 mb-3"><?php echo e(Auth::user()->name); ?></h2>
          <button type="submit" class="btn btn-secondary btn-sm d-inline-flex align-items-center">
            <svg class="icon icon-xxs me-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>            
            تسجيل الخروج
          </button>
        </div>
        </form>
      </div>
      <div class="collapse-close d-md-none">
        <a href="#sidebarMenu" data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="true"
            aria-label="Toggle navigation">
            <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
          </a>
      </div>
    </div>
    <ul class="nav flex-column pt-3 pt-md-0">
      
      <li class="nav-item">
        <a href="<?php echo e(route('index')); ?>" class="nav-link d-flex align-items-center">
          <span class="sidebar-icon">
            <img src="<?php echo e(asset('assets/img/favicon/logo-2.png')); ?>" height="20" width="20" alt="Volt Logo">
          </span>
          <span class="mt-1 ms-1 sidebar-text">SIT المصدر</span>
        </a>
      </li>

      
      <li class="nav-item active">
        <a href="<?php echo e(route('index')); ?>" class="nav-link">
          <span class="sidebar-icon">
            <svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path><path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path></svg>
          </span> 
          <span class="sidebar-text">الرئيسية</span>
        </a>
      </li>

      <?php if(!Auth::guest() && (Auth::user()->auth != "regular")): ?>
      
      <li class="nav-item">
        <span
          class="nav-link  collapsed  d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse" data-bs-target="#user-components">
          <span>
            <span class="sidebar-icon">
              <i class="fa fa-users"></i>
            </span> 
            <span class="sidebar-text">الموظفين</span>
          </span>
          <span class="link-arrow">
            <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
          </span>
        </span>
        <div class="multi-level collapse " role="list"
          id="user-components" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('users.create')); ?>">
                <span class="sidebar-text">اضافة موظف</span>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                <span class="sidebar-text">قائمة الموظفين</span>
              </a>
            </li>
          </ul>
        </div>
      </li>

      
      <li class="nav-item">
        <span
          class="nav-link  collapsed  d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse" data-bs-target="#client-components">
          <span>
            <span class="sidebar-icon">
              <i class="fa fa-users"></i>
            </span> 
            <span class="sidebar-text">العملاء</span>
          </span>
          <span class="link-arrow">
            <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
          </span>
        </span>
        <div class="multi-level collapse " role="list"
          id="client-components" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('clients.create')); ?>">
                <span class="sidebar-text">اضافة عميل</span>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('clients.index')); ?>">
                <span class="sidebar-text">قائمة العملاء</span>
              </a>
            </li>
          </ul>
        </div>
      </li>

      
      <li class="nav-item">
        <span
          class="nav-link  collapsed  d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse" data-bs-target="#projects-components">
          <span>
            <span class="sidebar-icon">
              <i class="fa fa-list"></i>
            </span> 
            <span class="sidebar-text">المشاريع</span>
          </span>
          <span class="link-arrow">
            <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
          </span>
        </span>
        <div class="multi-level collapse " role="list"
          id="projects-components" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('projects.create')); ?>">
                <span class="sidebar-text">اضافة مشروع</span>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
                <span class="sidebar-text">قائمة المشاريع</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>

      
      <li class="nav-item">
        <a href="<?php echo e(route('own_tasks')); ?>" class="nav-link">
          <span class="sidebar-icon">
            <i class="fa fa-tasks"></i>
          </span> 
          <span class="sidebar-text">المهام</span>
        </a>
      </li>

      <?php if(!Auth::guest() && (Auth::user()->auth != "regular")): ?>
          
          <li class="nav-item">
            <span
              class="nav-link  collapsed  d-flex justify-content-between align-items-center"
              data-bs-toggle="collapse" data-bs-target="#permissions-components">
              <span>
                <span class="sidebar-icon">
                  <i class="fa fa-columns"></i>
                </span> 
                <span class="sidebar-text">الاذونات</span>
                <?php if($new_requests > 0): ?>
                  <span style="float: unset" class="badge bg-success"><?php echo e($new_requests); ?></span>
                <?php endif; ?>
              </span>
              <span class="link-arrow">
                <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
              </span>
            </span>
            <div class="multi-level collapse " role="list"
              id="permissions-components" aria-expanded="false">
              <ul class="flex-column nav">
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('prequest.index2')); ?>">
                    <span class="sidebar-text">الطلبات الحالية</span>
                    <?php if($new_requests > 0): ?>
                      <span style="float: right" class="badge bg-success"><?php echo e($new_requests); ?></span>
                    <?php endif; ?>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('prequest.index3')); ?>">
                    <span class="sidebar-text">طلبات سابقة</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('prequest.index')); ?>">
                    <span class="sidebar-text">الاذونات الشخصية</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>

          
          <li class="nav-item">
            <span
              class="nav-link  collapsed  d-flex justify-content-between align-items-center"
              data-bs-toggle="collapse" data-bs-target="#vacations-components">
              <span>
                <span class="sidebar-icon">
                  <i class="fa fa-calendar"></i>
                </span> 
                <span class="sidebar-text">الاجازات</span>
                <?php if($vacation_requests > 0): ?>
                  <span style="float: unset" class="badge bg-success"><?php echo e($vacation_requests); ?></span>
                <?php endif; ?>
              </span>
              <span class="link-arrow">
                <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
              </span>
            </span>
            <div class="multi-level collapse " role="list"
              id="vacations-components" aria-expanded="false">
              <ul class="flex-column nav">
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('vrequest.index2')); ?>">
                    <span class="sidebar-text">الطلبات الحالية</span>
                    <?php if($vacation_requests > 0): ?>
                      <span style="float: right" class="badge bg-success"><?php echo e($vacation_requests); ?></span>
                    <?php endif; ?>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('vrequest.index3')); ?>">
                    <span class="sidebar-text">طلبات سابقة</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('vrequest.index')); ?>">
                    <span class="sidebar-text">الاجازات الشخصية</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>

          
          <li class="nav-item">
            <span
              class="nav-link  collapsed  d-flex justify-content-between align-items-center"
              data-bs-toggle="collapse" data-bs-target="#attendance-components">
              <span>
                <span class="sidebar-icon">
                  <i class="fa fa-plus"></i>
                </span> 
                <span class="sidebar-text">طلبات ملف الحضور</span>
                <?php if($attendanceRequests > 0): ?>
                <span style="float: unset" class="badge bg-success"><?php echo e($attendanceRequests); ?></span>
              <?php endif; ?>
              </span>
              <span class="link-arrow">
                <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
              </span>
            </span>
            <div class="multi-level collapse " role="list"
              id="attendance-components" aria-expanded="false">
              <ul class="flex-column nav">
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('att-file.index')); ?>">
                    <span class="sidebar-text">طلبات الموظفين</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('att-file.index2')); ?>">
                    <span class="sidebar-text">الطلبات الشخصية</span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
        <?php else: ?>
          
          <li class="nav-item">
            <a href="<?php echo e(route('prequest.index')); ?>" class="nav-link">
              <span class="sidebar-icon">
                <i class="fa fa-columns"></i>
              </span> 
              <span class="sidebar-text">الاذونات</span>
            </a>
          </li>

          
          <li class="nav-item">
            <a href="<?php echo e(route('vrequest.index')); ?>" class="nav-link">
              <span class="sidebar-icon">
                <i class="fa fa-calendar"></i>
              </span> 
              <span class="sidebar-text">الاجازات</span>
            </a>
          </li>

          
          <li class="nav-item">
            <a href="<?php echo e(route('att-file.index2')); ?>" class="nav-link">
              <span class="sidebar-icon">
                <i class="fa fa-plus"></i>
              </span> 
              <span class="sidebar-text">طلبات ملف الحضور</span>
            </a>
          </li>
      <?php endif; ?>

      <?php if(!Auth::guest() && (Auth::user()->auth != "regular")): ?>
      
      <li class="nav-item">
        <span
          class="nav-link  collapsed  d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse" data-bs-target="#contract-components">
          <span>
            <span class="sidebar-icon">
              <i class="fa fa-clone"></i>
            </span> 
            <span class="sidebar-text">العقود</span>
          </span>
          <span class="link-arrow">
            <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
          </span>
        </span>
        <div class="multi-level collapse " role="list"
          id="contract-components" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('contract.create')); ?>">
                <span class="sidebar-text">اضافة عقد جديد</span>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('contract.index')); ?>">
                <span class="sidebar-text">قائمة العقود</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>


<main class="content">
<nav class="navbar navbar-top navbar-expand navbar-dashboard navbar-dark ps-0 pe-2 pb-0 print-container">
  <div class="container-fluid px-0">
    <div class="d-flex justify-content-between w-100" id="navbarSupportedContent">
      <div class="d-flex align-items-center">
        <a href="javascript:location.reload(true)"><i class="fa fa-refresh"></i></a>
        <!-- Search form -->
        
        <!-- / Search form -->
      </div>
      <!-- Navbar links -->
      <ul class="navbar-nav align-items-center">
        <li class="nav-item dropdown">
          <a class="nav-link text-dark notification-bell unread dropdown-toggle" data-unread-notifications="true" href="#" role="button" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
            <svg class="icon icon-sm text-gray-900" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"></path></svg>
          </a>
          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-center mt-2 py-0">
            <div class="list-group list-group-flush">
              <p class="text-center text-primary fw-bold border-bottom border-light py-3">الاشعارات</p>
              <div class="col ps-0 ms-2">
                <p class="font-small mt-1 mb-0">لا يوجد اشعارات جديدة</p>
              </div>
            </div>
          </div>
        </li>
        <li class="nav-item dropdown ms-lg-3">
          <a class="nav-link dropdown-toggle pt-1 px-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <div class="media d-flex align-items-center">
              <?php if(Auth::user()->gender == "male"): ?>
                  <img class="avatar rounded-circle" alt="Image placeholder" src="<?php echo e(asset('assets/img/team/male.png')); ?>">
              <?php else: ?>
                  <img class="avatar rounded-circle" alt="Image placeholder" src="<?php echo e(asset('assets/img/team/female.png')); ?>">
              <?php endif; ?>
              <div class="media-body ms-2 text-dark align-items-center d-none d-lg-block">
                <span class="mb-0 font-small fw-bold text-gray-900"><?php echo e(Auth::user()->name); ?></span>
              </div>
            </div>
          </a>
          <div class="dropdown-menu dashboard-dropdown dropdown-menu-end mt-2 py-1">
            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('users.edit',Auth::user()->id)); ?>">
              <svg class="dropdown-icon text-gray-400 me-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-2.084A5 5 0 0010 11z" clip-rule="evenodd"></path></svg>
              الحساب الشخصي
            </a>
          <form action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div role="separator" class="dropdown-divider my-1"></div>
              <button class="dropdown-item d-flex align-items-center" type="submit">
                <svg class="dropdown-icon text-danger me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>                
                تسجيل الخروج
              </button>
            </div>
          </form>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\sithr\resources\views/layout/navbar.blade.php ENDPATH**/ ?>