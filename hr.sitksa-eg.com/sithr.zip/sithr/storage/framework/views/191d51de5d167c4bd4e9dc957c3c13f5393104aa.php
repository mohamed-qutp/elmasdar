

<?php $__env->startSection('title', 'الاذونات'); ?>
<?php $__env->startSection('t2','/الاذونات'); ?>
<?php $__env->startSection('pagetitle','الاذونات'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">الموظف</th>
                        <th class="border-0">تاريخ انشاء الطلب</th>
                        <th class="border-0">تفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($permissions) > 0): ?>
                    <?php echo e($permissions->links("pagination::bootstrap-4")); ?>

                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($permissions->id); ?></td>
                        <td><?php echo e($permissions->employee->name); ?></td>
                        <td><?php echo e($permissions->created_at); ?></td>
                        <td><a href="<?php echo e(route('prequest.show',$permissions->id)); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sitteam/public_html/sithr/resources/views/pages/permissions/permissions_index2.blade.php ENDPATH**/ ?>