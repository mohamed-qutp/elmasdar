

<?php $__env->startSection('title', 'تعديل الموظف'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/تعديل الموظف'); ?>
<?php $__env->startSection('pagetitle','تعديل الموظف'); ?>
<?php $__env->startSection('body'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('users.update',$users->id)); ?>" autocomplete="off" method="post">
    <input type="hidden" name="_method" value="PUT" />
    <?php echo csrf_field(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control" value="<?php echo e($users->name); ?>" name="name" id="name" placeholder="الاسم" required>
                                <small class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="email">البريد الالكتروني</label>
                                <input type="email" name="email" class="form-control" value="<?php echo e($users->email); ?>" id="email" placeholder="البريد الالكتروني" aria-describedby="emailHelp" required>
                                <small id="emailHelp" class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <?php if(Auth::user()->id == $users->id): ?>
                            <!-- Form -->
                            <div class="mb-4">
                                <label for="exampleInputIconPassword">الصلاحيات</label>
                                <input type="text" class="form-control-plaintext" readonly name="auth" value="<?php echo e($users->auth); ?>" id="auth">
                                <small id="emailHelp" class="form-text text-muted">* مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <?php else: ?>
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="exampleInputIconPassword">الصلاحيات</label>
                                <div class="input-group">
                                    <select class="form-select" name="auth"  aria-label="Default select example">
                                        <option <?php echo e($users->auth == "admin"  ? 'selected' : ''); ?> value="admin">Admin</option>
                                        <option <?php echo e($users->auth == "hr"  ? 'selected' : ''); ?> value="hr">HR</option>
                                        <option <?php echo e($users->auth == "regular"  ? 'selected' : ''); ?> value="regular">Regular</option>
                                    </select>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <?php endif; ?>
                            <!-- Form -->
                            <div class="mb-4">
                                <label for="national_id">رقم البطاقة</label>
                                <input type="text" class="form-control" name="national_id" value="<?php echo e($users->national_id); ?>" id="national_id" placeholder="رقم البطاقة المكون من 14 رقم">
                                <small id="emailHelp" class="form-text text-muted">غير مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="usernameValidate">اسم المستخدم</label>
                                <input type="text" class="form-control" name="username" value="<?php echo e($users->username); ?>" id="usernameValidate" placeholder="اسم المستخدم" required>
                                <small id="emailHelp" class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <!-- Form -->
                            <div class="mb-3">
                                <label class="my-1 me-2" for="gender">النوع</label>
                                <select class="form-select" name="gender" aria-label="Default select example">
                                    <option selected>اختر</option>
                                    <option <?php echo e($users->gender == "female"  ? 'selected' : ''); ?> value="female">انثى</option>
                                    <option <?php echo e($users->gender == "male"  ? 'selected' : ''); ?> value="male">ذكر</option>
                                </select>
                                <small id="emailHelp" class="form-text text-muted">غير مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="exampleInputIconPassword">اذونات</label>
                                <div class="input-group">
                                    <input class="form-control" <?php echo e($users->id == Auth::user()->id  ? 'readonly' : ''); ?> value="<?php echo e($users->permission); ?>" name="permission" type="text">
                                </div>
                                <small id="emailHelp" class="form-text text-muted">غير مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <?php if(Auth::user()->id == $users->id): ?>
                            <!-- Form -->
                            <div class="mb-4">
                                <a href="<?php echo e(route('change-pass',Auth::user()->id)); ?>" class="btn btn-rounded btn-primary">تغيير كلمة السر</a>
                            </div>
                            <!-- End of Form -->
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="birthday">رقم الجوال</label>
                                <div class="input-group">
                                    <input name="phone_number" value="<?php echo e($users->phone_number); ?>" class="form-control" id="phone_number" type="text" placeholder="رقم الجوال" required>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">* مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="birthday">تاريخ الميلاد</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                                    </span>
                                    <input name="birthdate" value="<?php echo e($users->birth_date); ?>" class="form-control" type="date">
                                </div>
                                <small id="emailHelp" class="form-text text-muted">غير مطلوب</small>
                            </div>
                            <!-- End of Form -->
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="exampleInputIconPassword">اجازات</label>
                                <div class="input-group">
                                    <input class="form-control" <?php echo e($users->id == Auth::user()->id  ? 'readonly' : ''); ?> value="<?php echo e($users->vacations); ?>" name="vacations" type="text">
                                </div>
                                <small id="emailHelp" class="form-text text-muted">غير مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <button class="btn btn-secondary" name="save" type="submit">تعديل</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/users/useredit.blade.php ENDPATH**/ ?>