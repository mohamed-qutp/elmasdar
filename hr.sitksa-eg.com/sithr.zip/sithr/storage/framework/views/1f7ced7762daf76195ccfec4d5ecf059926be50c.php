

<?php $__env->startSection('title', 'الاجازات'); ?>
<?php $__env->startSection('t2','/الاجازات'); ?>
<?php $__env->startSection('pagetitle','الاجازات'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">الموظف</th>
                        <th class="border-0">تاريخ انشاء الطلب</th>
                        <th class="border-0">تفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($vacations) > 0): ?>
                    <?php echo e($vacations->links("pagination::bootstrap-4")); ?>

                        <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vacations->id); ?></td>
                        <td><?php echo e($vacations->employee->name); ?></td>
                        <td><?php echo e($vacations->created_at); ?></td>
                        <td><a href="<?php echo e(route('vrequest.show',$vacations->id)); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/vacations/vacations_index2.blade.php ENDPATH**/ ?>