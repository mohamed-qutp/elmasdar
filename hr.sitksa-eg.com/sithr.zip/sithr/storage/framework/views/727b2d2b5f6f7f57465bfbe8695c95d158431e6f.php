<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home3/ilcruumy/public_html/sitksa-hr/sithr/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>