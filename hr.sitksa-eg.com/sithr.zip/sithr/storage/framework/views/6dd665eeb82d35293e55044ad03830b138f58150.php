

<?php $__env->startSection('title', 'تفاصيل العميل'); ?>
<?php $__env->startSection('t2','/العملاء'); ?>
<?php $__env->startSection('t3','/تفاصيل العميل'); ?>
<?php $__env->startSection('pagetitle','تفاصيل العميل'); ?>
<?php $__env->startSection('body'); ?>

<form autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control-plaintext" readonly value="<?php echo e($client->name); ?>" name="name" id="name" placeholder="الاسم" required>

                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="phone_number">رقم الجوال</label>
                                <input name="phone_number" value="<?php echo e($client->phone_number); ?>" class="form-control-plaintext" readonly id="phone_number" type="text" placeholder="لا يوجد" required>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="address">العنوان</label>
                                <div class="input-group">
                                    <input name="address" value="<?php echo e($client->address); ?>" class="form-control-plaintext" readonly id="address" type="text" placeholder="لا يوجد" required>
                                </div>

                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <a class="btn btn-primary" href="<?php echo e(route('client_project',$client->id)); ?>" type="submit">عرض المشاريع</a>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <a class="btn btn-secondary" href="<?php echo e(route('clients.edit',$client->id)); ?>" type="submit">تعديل بيانات العميل</a>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <form method="get" action="<?php echo e(route('clients.destroy',$client->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="hidden" name="_method" value="DELETE" />
                                    <a data-bs-toggle="modal" data-bs-target="#delete" class="btn btn-danger">حذف العميل</a>
                                </form>
                            </div>
                        </div>
                        <!--                                 delete                                             -->
                        <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">حذف العميل</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        هل تريد حذف العميل
                                    </div>
                                    <div class="modal-footer">
                                            <input type="hidden" name="_method" value="DELETE" />
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">الغاء</button>
                                            <button type="submit" class="btn btn-danger me-2">حذف </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/clients/client_show.blade.php ENDPATH**/ ?>