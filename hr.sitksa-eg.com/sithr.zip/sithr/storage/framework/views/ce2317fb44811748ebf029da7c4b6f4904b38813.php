

<?php $__env->startSection('title', 'عرض مهام الموظف'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/عرض مهام الموظف'); ?>
<?php $__env->startSection('pagetitle','عرض مهام الموظف'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">اسم المهمة</th>
                        <th class="border-0">مكلفة من</th>
                        <th class="border-0">الحالة</th>
                        <th class="border-0">التفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($tasks) > 0): ?>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($task->title); ?></td>
                        <td><?php echo e($task->users->name); ?></td>
                        <?php if($task->done == 0): ?>
                            <td>قيد التنفيذ</td>
                        <?php else: ?>
                            <td>تم التنفيذ</td>
                        <?php endif; ?>
                        <td><a href="<?php echo e(route('user_tasks_show',$task->id)); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>لا يوجد مهام</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/tasks/user_tasks.blade.php ENDPATH**/ ?>