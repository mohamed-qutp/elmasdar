

<?php $__env->startSection('title', 'تفاصيل الموظف'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/تفاصيل الموظف'); ?>
<?php $__env->startSection('pagetitle','تفاصيل الموظف'); ?>
<?php $__env->startSection('body'); ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('destroy_user',$users->id)); ?>" method="post">
    <div class="col-lg-4 col-sm-6">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="DELETE">
        <input type="submit" class="btn btn-danger" value="حذف الموظف">
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/users/deletionalert.blade.php ENDPATH**/ ?>