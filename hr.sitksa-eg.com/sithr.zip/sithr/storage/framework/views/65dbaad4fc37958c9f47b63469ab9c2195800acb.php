

<?php $__env->startSection('title', 'طلبات ملف الحضور'); ?>
<?php $__env->startSection('t2','/طلبات ملف الحضور'); ?>
<?php $__env->startSection('pagetitle','طلبات ملف الحضور'); ?>
<?php $__env->startSection('body'); ?>
<?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row rtl-form-section">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow components-section">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <label>صاحب الطلب</label>
                        <input type="text" class="form-control-plaintext" value="<?php echo e($attendance->users->name); ?>">
                    </div>
                    <div class="col-md-6">
                        <label>ملف شهر</label>
                        <input type="text" class="form-control-plaintext" value="<?php echo e($attendance->month); ?>">
                    </div>
                </div>
                <div class="row">
                    <?php if($attendance->file_path != null): ?>
                    <form action="<?php echo e(route('fileDownload',$attendance->id)); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-4">
                            <label> الملف</label></br>
                            <button type="submit" class="btn btn-info"><i class="fa fa-download"></i></button>
                        </div>
                    </form>
                    <?php else: ?>
                    <form autocomplete="off" action="<?php echo e(route('att-file.update',$attendance->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="col-md-4">
                            <label>الملف</label>
                            <input type="file" name="file" class="form-control">
                        </div>
                        <div class="col-md-4">
                            </br>
                            <input type="submit" name="submit" class="btn btn-success" value="حفظ">
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/attendance/attendance-show.blade.php ENDPATH**/ ?>