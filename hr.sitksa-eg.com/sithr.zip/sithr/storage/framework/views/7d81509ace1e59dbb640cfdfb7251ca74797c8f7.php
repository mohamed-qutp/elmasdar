

<?php $__env->startSection('title', 'تعديل الموظف'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/تعديل الموظف'); ?>
<?php $__env->startSection('pagetitle','تغيير كلمة السر'); ?>
<?php $__env->startSection('body'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('change-password',$users->id)); ?>" autocomplete="off" method="post">
    <input type="hidden" name="_method" value="PUT" />
    <?php echo csrf_field(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <small class="form-text text-muted bg-warning"><i class="fa fa-warning"></i> يجب أن تكون كلمات المرور مكونة من 8 حروف/ارقام او اكثر.</small>
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="password">كلمة السر الجديدة</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="كلمة السر الجديدة" required>
                                <small class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="confirmpassword">تأكيد كلمة السر الجديدة</label>
                                <input type="password" class="form-control" name="confirmpassword" id="confirmpassword" placeholder="تأكيد كلمة السر الجديدة" required>
                                <small id="emailHelp" class="form-text text-muted">*مطلوب</small>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <button class="btn btn-secondary" name="save" type="submit">تعديل</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/users/changePass.blade.php ENDPATH**/ ?>