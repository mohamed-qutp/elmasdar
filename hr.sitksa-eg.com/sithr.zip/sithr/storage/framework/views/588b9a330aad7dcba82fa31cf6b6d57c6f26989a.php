

<?php $__env->startSection('title', 'تفاصيل المشروع'); ?>
<?php $__env->startSection('t2','/المشاريع'); ?>
<?php $__env->startSection('t3','/تفاصيل المشروع'); ?>
<?php $__env->startSection('pagetitle','تفاصيل المشروع'); ?>
<?php $__env->startSection('body'); ?>

<form autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control-plaintext" readonly value="<?php echo e($projects->name); ?>" name="name" id="name" placeholder="الاسم" required>
                                
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="client">العميل</label>
                                <input name="client" value="<?php echo e($projects->client->name); ?>" class="form-control-plaintext" readonly id="client" type="text" placeholder="لا يوجد" required>
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <a class="btn btn-secondary" href="<?php echo e(route('projects.edit',$projects->id)); ?>" type="submit">تعديل بيانات المشروع</a>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <form method="get" action="<?php echo e(route('projects.destroy',$projects->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="hidden" name="_method" value="DELETE" />
                                    <button onclick="confirm('Delete entry?')" class="btn btn-danger">حذف المشروع</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/projects/project_show.blade.php ENDPATH**/ ?>