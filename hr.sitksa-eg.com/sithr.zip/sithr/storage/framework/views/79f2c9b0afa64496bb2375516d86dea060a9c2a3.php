

<?php $__env->startSection('title', 'قائمة الأقسام'); ?>
<?php $__env->startSection('t2','/الأقسام'); ?>
<?php $__env->startSection('t3','/عرض الأقسام'); ?>
<?php $__env->startSection('pagetitle','قائمة الأقسام'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">       
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">الاسم</th>
                        <th class="border-0">تفاصيل</th>
                        <th class="border-0">مسح</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($departments) > 0): ?>
                    <?php echo e($departments->links("pagination::bootstrap-4")); ?>

                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($department->name); ?></td>
                        <td><a href="<?php echo e(route('departments.show',$department->id)); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i></a></td>
                        <?php if(Auth::user()->auth == 'admin'): ?>
                        <form action="<?php echo e(route('departments.destroy',$department->id)); ?>" method="POST">
                          
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <td><button type="submit" class="btn btn-danger"><i class="fa-solid fa-xmark"></i></button></td>
                        </form>

                        <?php endif; ?>                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <!--                                 delete                                             -->
            <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">حذف القسم</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body">
                            هل تريد حذف القسم </div>
                        <div class="modal-footer">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sithr\resources\views/pages/departments/departments.blade.php ENDPATH**/ ?>