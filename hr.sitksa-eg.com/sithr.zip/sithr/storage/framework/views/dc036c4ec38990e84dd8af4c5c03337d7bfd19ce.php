

<?php $__env->startSection('title', 'الاجازات'); ?>
<?php $__env->startSection('t2','/الاجازات'); ?>
<?php $__env->startSection('pagetitle','الاجازات'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">تاريخ  بداية الاجازة</th>
                        <th class="border-0">تاريخ  نهاية الاجازة</th>
                        <th class="border-0">الحالة</th>
                        <th class="border-0">تفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($vacations) > 0): ?>
                    <?php echo e($vacations->links("pagination::bootstrap-4")); ?>

                        <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vacation->id); ?></td>
                        <td><?php echo e($vacation->date_from); ?></td>
                        <td><?php echo e($vacation->date_to); ?></td>
                        <?php if($vacation->status == 'pending'): ?>
                        <td><div class="badge bg-warning" style="padding: 5px;font-size:1em;color:black">تحت المراجعة</div></td>
                        <?php elseif($vacation->status == 'accepted'): ?>
                        <td><div class="badge bg-success" style="padding: 5px;font-size:1em;color:black">مقبول</div></td>
                        <?php elseif($vacation->status == 'rejected'): ?>
                        <td><div class="badge bg-danger" style="padding: 5px;font-size:1em;color:black">مرفوض</div></td>
                        <?php elseif($vacation->status == 'cancelled'): ?>
                        <td><div class="badge bg-light" style="padding: 5px;font-size:1em;color:black">ملغي</div></td>
                        <?php endif; ?>
                        <td><a href="<?php echo e(route('vrequest.show',$vacation->id)); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/vacations/vacations_index.blade.php ENDPATH**/ ?>