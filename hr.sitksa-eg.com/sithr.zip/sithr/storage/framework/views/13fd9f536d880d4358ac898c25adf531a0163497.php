

<?php $__env->startSection('title', 'قائمة المشاريع'); ?>
<?php $__env->startSection('t2','/العملاء'); ?>
<?php $__env->startSection('t3','/عرض المشاريع'); ?>
<?php $__env->startSection('pagetitle','قائمة المشاريع'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">الاسم</th>
                        <th class="border-0">تفاصيل</th>
                        <th class="border-0">مسح</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($projects) > 0): ?>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($project->name); ?></td>
                        <td><a href="<?php echo e(route('projects.show',$project->id)); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i></a></td>
                        <form method="post" action="<?php echo e(route('projects.destroy',$project->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <td><a data-bs-toggle="modal" data-bs-target="#delete" class="btn btn-danger"><i class="fa-solid fa-xmark"></i></a></td>
                        </form>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>لا يوجد مشاريع لهذا العميل</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <!--                                 delete                                             -->
            <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">حذف المشروع</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body">
                            هل تريد حذف المشروع </div>
                        <div class="modal-footer">

                            <input type="hidden" name="_method" value="DELETE" />
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">الغاء</button>
                            <button type="submit" class="btn btn-danger me-2">حذف </button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\sithr\resources\views/pages/clients/client_projects.blade.php ENDPATH**/ ?>