

<?php $__env->startSection('title', 'تعديل الموظف'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/تعديل الموظف'); ?>
<?php $__env->startSection('pagetitle','تعديل الموظف'); ?>
<?php $__env->startSection('body'); ?>

<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('clients.update',$clients->id)); ?>" autocomplete="off" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <div class="row rtl-form-section">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow components-section">
                <div class="card-body">     
                    <div class="row mb-4">
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="name">الاسم</label>
                                <input type="text" class="form-control" value="<?php echo e($clients->name); ?>" name="name" id="name" placeholder="الاسم" required>
                                
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="phone_number">رقم الجوال</label>
                                <input name="phone_number" value="<?php echo e($clients->phone_number); ?>" class="form-control" id="phone_number" type="text" placeholder="رقم الجوال">
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <!-- Form -->
                            <div class="mb-3">
                                <label for="address">العنوان</label>
                                <div class="input-group">
                                    <input name="address" value="<?php echo e($clients->address); ?>" class="form-control" id="address" type="text" placeholder="العنوان">
                                </div>
                                
                            </div>
                            <!-- End of Form -->
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <button class="btn btn-secondary" name="update" type="submit">تعديل</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sithr\resources\views/pages/clients/client_edit.blade.php ENDPATH**/ ?>