

<?php $__env->startSection('title', 'قائمة الموظفين'); ?>
<?php $__env->startSection('t2','/الموظفين'); ?>
<?php $__env->startSection('t3','/عرض الموظفين'); ?>
<?php $__env->startSection('pagetitle','قائمة الموظفين'); ?>
<?php $__env->startSection('body'); ?>
<div class="card border-0 shadow mb-4">

    <div class="card-body">

        <div class="table-responsive">
            <div class="d-flex justify-content-between">
                <?php if(Auth::user()->auth == 'admin'): ?>
                <a class="btn btn-secondary mb-3" href="<?php echo e(route('users.create')); ?>">اضافة</a>
                <h6 class=" my-3">اضافة موظف جديد</h6>
                <?php endif; ?>
            </div>
            <table class="table table-centered table-nowrap mb-0 rounded">
                <thead class="thead-light">
                    <tr>
                        <th class="border-0 rounded-start">#</th>
                        <th class="border-0">الاسم</th>
                        <th class="border-0">اسم المستخدم</th>
                        <th class="border-0">تفاصيل</th>
                        <?php if(Auth::user()->auth == 'admin'): ?>
                        <th class="border-0">مسح</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($users) > 0): ?>
                    <?php echo e($users->links("pagination::bootstrap-4")); ?>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><a href="<?php echo e(route('users.show',$user->id)); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i></a></td>
                        <?php if(Auth::user()->auth == 'admin'): ?>
                        <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                          
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <td><button type="submit" class="btn btn-danger"><i class="fa-solid fa-xmark"></i></button></td>
                        </form>

                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sithr\resources\views/pages/users/showusers.blade.php ENDPATH**/ ?>