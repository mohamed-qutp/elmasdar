@extends('layout.header')

@section('title', 'قائمة الموظفين')
@section('t2','/الموظفين')
@section('t3','/عرض الموظفين')
@section('pagetitle','قائمة الموظفين')
