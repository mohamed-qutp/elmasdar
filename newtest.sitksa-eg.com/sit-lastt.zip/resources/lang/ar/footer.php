<?php
return 
[
    'getintouch'=>'تواصل معنا',
    'contactus'=>'اتصل بنا',
    'askforaquotation'=>' احصل على عرض سعر',
    'agentlogin'=>'دخول الموظفين',
    'officelocations'=>'مواقعنا',
    'sitemap'=>'خريطة الموقع',
    'company' => 'الشركة',
    'aboutSITpeople'=>'عن مجتمع المصدر',
    'downloadthePortfolio'=>'تحميل البروفايل',
    'careers' => 'التوظيف',
    'services' => 'الخدمات',
    'erpsystem'=>'	أنظمة تخطيط موارد المؤسسات ',
    'possystem'=>'	أنظمة نقاط البيع ',
    'webdevelopment'=>'تطوير المواقع الالكترونية',
    'mobileapplication'=>'تطبيقات الجوال',
    'webapplication'=>'تطبيقات الويب',
    'cybersecurity'=>'الأمن السيبرانى',
    'digitalmarketing'=>'التسويق الرقمى',
    'customersupport'=>'الدعم التقني',    
];