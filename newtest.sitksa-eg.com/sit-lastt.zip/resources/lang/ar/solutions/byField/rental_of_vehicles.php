<?php
return
[
    'solutiontitle'=>'مجال تأجير السيارات',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال تأجير السيارات ينقسم إلى:',    
    'solutionclassificationone'=>'• حركة المستودعات',
    'solutionclassificationonefeatures'=>'
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	تعريف السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	المستودعات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	أنشطة التأجير<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	الورش<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	بنود إجراءات التأجير<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	مكاتب تأجير السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	موظفي مكتب التأجير<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	مصروفات التأجير<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	أنواع التأمينات',
    'solutionclassificationtwo'=>'  •	إعدادات برنامج التأجير',
    'solutionclassificationtwofeatures'=>'
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	عقد تأجير السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	حركات المستودعات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	تحويل السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	تسليم السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	استلام السيارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	الاستعلامات        
    ',
];