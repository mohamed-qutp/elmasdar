<?php
return
[
    'solutiontitle'=>'مجال الإنتاج الصناعي',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال الإنتاج الصناعي ينقسم إلى:',
    'solutionclassificationone'=>' البيانات الأساسية',
    'solutionclassificationonefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	سجل الماكينات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	عمال الإنتاج<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	الموارد<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	معدلات الإنتاج    
    ',
    'solutionclassificationtwo'=>' الحركات',
    'solutionclassificationtwofeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>طلبيات العملاء<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>عروض الأسعار<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>أوامر الشغل<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>تشغيلات الإنتاج- معادلة الإنتاج      
    ',
    'solutionclassificationthree'=>'المراجعة والتدقيق',
    'solutionclassificationthreefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	فك تفعيل عروض الأسعار<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	فك أمر الإنتاج<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	فك أمر الشغل<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	فك تشغيلات الإنتاج    
    ',    
];