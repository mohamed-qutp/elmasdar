<?php
return
[
    'solutiontitle'=>'مجال المطاعم والمطابخ ',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال المطاعم والمطابخ ينقسم إلى:',
    'solutionclassificationone'=>' قائمة التكويد',
    'solutionclassificationonefeatures'=>'	<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	 تكويد فرع<br/>
	<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	 تكويد صنف<br/>
	<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تكويد كمية وسعر<br/>
	<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	 تكويد تصنيفات الجلسة
    ',
    'solutionclassificationtwo'=>' تقرير إجمالي الفواتير',    
    'solutionclassificationthree'=>'  حركة المخزن',
    'solutionclassificationthreefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	إذن وارد<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>		إذن إضافة مخزنية<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	إذن تحويل<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تقرير حركة المخزن    
    ',    
];