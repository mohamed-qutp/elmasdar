<?php
return
[
    'solutiontitle'=>'مجال المؤسسات التعليمية',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال المؤسسات التعليمية ينقسم إلى:',
    
    'solutionclassificationonefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تعريف الجامعات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تعريف الكليات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تعريف المواد الدراسية<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تعريف العملاء<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	بيانات الطلاب<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	التشغيل<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	المبيعات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	تسجيل الطلاب<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	سداد المصروفات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> الاستعلامات<br/>
    ',    
];