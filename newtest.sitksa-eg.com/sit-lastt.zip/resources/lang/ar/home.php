<?php
return 
[
    'ourservices'=>'الخدمات',
    'erpsystem'=>'أنظمة تخطيط موارد المؤسسات',
    'possystem'=>'أنظمة نقاط البيع',
    'webdevelopment'=>'تطوير المواقع الالكترونية',
    'mobileapplication'=>'تطبيقات الجوال',
    'webapplication'=>'تطبيقات الويب',
    'cybersecurity'=>'الأمن السيبرانى',
    'digitalmarketing'=>'التسويق الرقمى',
    'customersupport'=>'الدعم التقنى',
    'ourclients'=>'عملائنا',
    'ourlocations'=>'مواقعنا',
];