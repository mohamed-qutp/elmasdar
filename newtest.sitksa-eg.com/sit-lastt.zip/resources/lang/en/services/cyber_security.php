<?php
return
[
    'servicetitle'=>'Cyber Security',
    'servicedescription'=>'Given recent advances surrounding our complete reliance on digital technology and communications in many parts of life, cybersecurity is essential in today’s world. These steps are taken to protect the confidentiality and integrity of data as well as the continuation of people, businesses, and institutions’ vital operations.
    It is a collection of technical measures designed to safeguard data, networks, and computer systems from cybercrime and cyberattacks. Electronic fraud, identity theft, and new threats are just a few of the dangers and difficulties that go under the umbrella of cybersecurity.
    ',
];