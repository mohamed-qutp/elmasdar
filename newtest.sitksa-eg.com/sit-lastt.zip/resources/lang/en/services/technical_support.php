<?php
return
[
    'servicetitle'=>'Technical Support',
    'servicedescription'=>'In the source of the information technology, we provide a range of services and procedures aimed at helping clients solve their technical problems and queries about digital systems. Technical support services are provided through multiple means and platforms to be on your side whenever you need us. 
    Technical support provides guidance and training to users to help them understand how to use technology better and more effectively. Technical support also includes maintenance of systems, including installation of security corrections, upgrades and software upgrades, which helps to provide positive experience to clients and ensure systems function properly and effectively.
    ',
];