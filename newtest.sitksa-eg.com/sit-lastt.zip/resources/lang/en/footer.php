<?php
return
[
  'getintouch'=>'Get in Touch',
  'contactus'=>'Contact us',
  'askforaquotation'=>'Ask for a Quotation',
  'agentlogin'=>'Agent Login',
  'officelocations'=>'Office Locations',
  'sitemap'=>'Site Map',
  'company' => 'Company',
  'aboutSITpeople'=>'About SITpeople',
  'downloadthePortfolio'=>'Download the Portfolio',
  'careers' => 'Careers',
  'services' => 'Services',
  'erpsystem'=>'ERP System',
  'possystem'=>'POS System',
  'webdevelopment'=>'Web Development',
  'mobileapplication'=>'Mobile Application',
  'webapplication'=>'Web Application',
  'cybersecurity'=>'Cyber Security',
  'digitalmarketing'=>'Digital Marketing',
  'customersupport'=>'Technical Support',
];