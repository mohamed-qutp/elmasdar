<?php
return
[
    'solutiontitle'=>'Financial Management ',
    'solutionadvantagesbasetitle'=>'Advantages of the public accounting ERP system:',
    'solutionadvantage1'=>'A multi-stage finance manual',
    'solutionadvantage2'=>'Sub-cost centers',
    'solutionadvantage3'=>'Flexible financial moves',
    'solutionadvantage4'=>'The possibility of establishing types of regulation of restrictions and types of regulation of movements',
    'solutionadvantage5'=>'Careful follow-up of the ledger and review scale',
    'solutionadvantage6'=>'A direct link between the Finance Manual and the cost centers',
    'solutionadvantage7'=>'The possibility of linking the statute to another system',
    'solutionadvantage8'=>'Cloud system for unlimited number of users',
    'solutionadvantage9'=>'High insurance system',
    'solutionadvantage10'=>'Absorbing a large volume of data',
    'solutionadvantage11'=>'Possibility of managing more than one financial period and more than one fiscal year',    
];