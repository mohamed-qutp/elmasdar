<?php
return
[
    'solutiontitle'=>'Supply Chain Management',
    'solutionadvantagesbasetitle'=>'Advantages of the supply chain management ERP system:',
    'solutionadvantage1'=>'Establishment of a non-exhaustive number of warehouses, whether major or subsidiary',
    'solutionadvantage2'=>'Tie each warehouse to a particular branch',
    'solutionadvantage3'=>'Subdivisional powers of warehouse owners',
    'solutionadvantage4'=>'Detailed management of sales pavilion activity',
    'solutionadvantage5'=>'Possibility of selling inside and outside the office',
    'solutionadvantage6'=>'Creation of instant customer bills',
    'solutionadvantage7'=>'The possibility of using purchase orders via electronic cloud',
    'solutionadvantage8'=>'Possibility of managing suppliers grace from item balances',
    'solutionadvantage9'=>'Possible integration with any supplier systems',
    'solutionadvantage10'=>'Possibility of accurate control over the calculation of each resource',
    
];