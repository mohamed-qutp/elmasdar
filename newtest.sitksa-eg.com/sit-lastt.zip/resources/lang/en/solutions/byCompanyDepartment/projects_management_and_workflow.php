<?php
return
[
    'solutiontitle'=>'Projects Management And Workflow',
    'solutionadvantagesbasetitle'=>'Advantages of the enterprise management and workflow ERP system:',
    'solutionadvantage1'=>'Control of all projects is being opened',
    'solutionadvantage2'=>'Determination of the schedule',
    'solutionadvantage3'=>'Identification of who is responsible for each phase and distribution of tasks',
    'solutionadvantage4'=>'Comparability of percentages in the planning process and percentages in the implementation process',
    'solutionadvantage5'=>'Possibility of oversight of staff and their own achievements',
    'solutionadvantage6'=>'Possibility of extracting a monthly or quarterly extract',
    'solutionadvantage7'=>'Control of project delivery',
    'solutionadvantage8'=>'Quality control of implementation process',   
];