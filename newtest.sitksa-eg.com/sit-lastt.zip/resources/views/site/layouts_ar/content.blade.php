@include('site.layouts.head')
<body>
@include('site.layouts_ar.header')
@include('site.layouts_ar.footer')
@include('site.layouts_ar.js')