<header class="main-header main-header-01 headroom navbar-light fixed-top navbar-transparent headroom--not-bottom headroom--not-top headroom--pinned" id="h_blur0">
  <nav role="navigation" class="navbar navbar-expand-lg">
  <div class="container">
<!-- Logo -->
 <a class="navbar-brand header-navbar-brand nav-mob logo-margin" href="/">
 <img class="logo-dark logo-img" src="<?php echo e(asset('assets/images/logo-2.png')); ?>" title="" alt=""> 
 <img class="logo-light logo-img" src="<?php echo e(asset('assets/images/logo-2.png')); ?>" title="" alt="" >
  </a>
  <a href="javascript:void(0);" class="ic menu" tabindex="1">
      <span class="line"></span>
      <span class="line"></span>
      <span class="line"></span>
    </a>
    <a href="javascript:void(0);" class="ic close"></a> 
     <!-- <div class="collapse navbar-collapse" id="navbarSupportedContent"> -->
    <ul class="main-nav justify-content-center">
      <!-- <li class="top-level-link">
        <a><span>Home</span></a>      
      </li>  -->
      
      <li class="top-level-link">
        <a class="mega-menu" id="services"><span><?php echo e(trans('header.services')); ?></span></a>
        <label class="px-dropdown-toggle mob-menu bi bi-chevron-down"></label>
        <div class="sub-menu-block px-mega-menu start-0" id="services_sub">
          <div class="row text-center" id="sub"> 
            <div class="col-sm-6 col-lg-4 my-3" id="sub1">
              <h2 class="sub-menu-head"></h2>   
              <ul class="sub-menu-lists sub-first-pad">
              <li><a class="dropdown-item text-end" href="<?php echo e(route('erp-systems')); ?>" id="home_link1"><?php echo e(trans('header.erpsystem')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('pos')); ?>" id="home_link2"><?php echo e(trans('header.possystem')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('web-development')); ?>"><?php echo e(trans('header.webdevelopment')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('mobile-applications')); ?>"><?php echo e(trans('header.mobileapplication')); ?></a></li>     
              </ul>           
            </div>
            <div class="col-sm-6 col-lg-4 my-3" id="sub2">
              <h2 class="sub-menu-head"></h2> 
              <ul class="sub-menu-lists sub-second-pad">
              <li><a class="dropdown-item text-end" href="<?php echo e(route('web-applications')); ?>"><?php echo e(trans('header.webapplication')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('cyber-security')); ?>"><?php echo e(trans('header.cybersecurity')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('digital-marketing')); ?>"><?php echo e(trans('header.digitalmarketing')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('technical-support')); ?>"><?php echo e(trans('header.customersupport')); ?></a></li>
              </ul>
            </div>
            <div class="col-sm-6 col-lg-4 my-3" id="sub3">
            <img src="<?php echo e(asset('assets/images/dummy.png')); ?>" id="home_img"/>
            </div>
          </div>        
        </div>
      </li>
      
      <li class="top-level-link">
        <a class="mega-menu" id="solutions"><span><?php echo e(trans('header.solutions')); ?></span></a>
        <div class="sub-menu-block px-mega-menu start-0" id="solutions_sub">
          <div class="row" id="s_sub">
            <div class="col-sm-6 col-lg-4 my-3" id="s_sub1">
            <h2 class="sub-menu-head text-end"><?php echo e(trans('header.byindustry')); ?></h2>
              <ul class="sub-menu-lists sub-first-pad"> 
                <li><a class="dropdown-item text-end" href="<?php echo e(route('real-estate')); ?>" id="page_link1"><?php echo e(trans('header.realestate')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('construction-and-Contracting')); ?>" id="page_link2"><?php echo e(trans('header.constructionsandcontracting')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('manufacturing-and-industrial-production')); ?>"><?php echo e(trans('header.manufacturingandindustrialproduction')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('educational-institutions')); ?>"><?php echo e(trans('header.education')); ?></a></li> 
                <li><a class="dropdown-item text-end" href="<?php echo e(route('rental-of-vehicles')); ?>"><?php echo e(trans('header.rentalofvehicles')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('restaurants-and-catering')); ?>"><?php echo e(trans('header.restaurantsandcaterings')); ?></a></li> 
              </ul>          
            </div>
            <div class="col-sm-6 col-lg-4 my-3" id="s_sub2">
            <h2 class="sub-menu-head text-end"><?php echo e(trans('header.bydepartment')); ?></h2>
              <ul class="sub-menu-lists sub-second-pad">
                <li><a class="dropdown-item text-end" href="<?php echo e(route('financial-management')); ?>"><?php echo e(trans('header.accounting')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('human-resources-management')); ?>"><?php echo e(trans('header.humancapitalmanagement')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('supply-chain-management')); ?>"><?php echo e(trans('header.supplychainmanagement')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('inventory-management')); ?>"><?php echo e(trans('header.inventory')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('project-management-and-workflow')); ?>"><?php echo e(trans('header.projectmanagementandworkflow')); ?></a></li>
                <li><a class="dropdown-item text-end" href="<?php echo e(route('tasks-management')); ?>"><?php echo e(trans('header.taskmanagementsystem')); ?></a></li> 
              </ul>
            </div>
            <div class="col-sm-6 col-lg-4 my-3" id="s_sub3">
            <img src="<?php echo e(asset('assets/images/dummy.png')); ?>" id="solution_img"/>
            </div>
          </div>
          
        </div>
      </li>
      <li class="top-level-link">
        <a href="<?php echo e(route('our-clients')); ?>" class="mega-menu" id="clients"><?php echo e(trans('header.clients')); ?></a>      
        
      </li>
    </ul> 
    <!-- </div> -->
    <!-- End Menu -->
     
    <div class="nav align-items-center elem-mr">
        
    
    <ul class="search-cart-area justify-content-center search-m">
                        <li class="search-icon" id="search_icon"><a href="#"><span class="fa fa-search" id="se_icon"></span></a></li>
                       
                    </ul>
    <a href="<?php echo e(route('demo-request')); ?>" class="btn btn-outline-white ms-2" id="dm"><?php echo e(trans('header.buynow')); ?></a><br/><br/><br/>  
  
    </div>  
    <p class="small mb-2 lang">
       <a class="text-reset" rel="alternate" hreflang="ar"  href="<?php echo e(LaravelLocalization::getLocalizedURL('ar', null, [], true)); ?>"style="font-size: 20px;font-weight: 900;font-variant: all-petite-caps;" >عربى</a> /
       <a class="text-reset" rel="alternate" hreflang="en"  href="<?php echo e(LaravelLocalization::getLocalizedURL('en', null, [], true)); ?>"style="font-size: 18px;font-weight: 600;font-variant: all-petite-caps;">انجليزى</a>  
</p>
</div> 
 </nav>
</header>

<div class="search-popup">
  <form class="search-form" method="get" action="#" target="_blank">
    <?php echo csrf_field(); ?>
    <div class="form-element"><input type="text" placeholder="    Type You Want  To Search   " name="code"></div>
  </form>
  <div class="search-popup-overlay" id="searchOverlay"></div>
  <button class="search-close-btn" id="searchCloseBtn"><i class="fas fa-times"></i></button>
</div><?php /**PATH /home/sitksaeg/public_html/newtest.sitksa-eg.com/resources/views/site/layouts_ar/header.blade.php ENDPATH**/ ?>