<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $__env->make('site.layouts_ar.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
    <div class="wrapper">
    <?php echo $__env->make('site.layouts_ar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4"><?php echo e(trans('solutions/byField/construction_and_contracting.solutiontitle')); ?></h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">الرئيسية</a></li>
                        <li class="breadcrumb-item active"><?php echo e(trans('solutions/byField/construction_and_contracting.solutiontitle')); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  
    <div id="video" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <!-- Video Preview -->
                    <div class="image-container">
                        <div class="video-wrapper">
                            <a class="popup-youtube" href="https://www.youtube.com/watch?v=fLCjQJCekTs" data-effect="fadeIn">
                               
                                <span class="video-play-button">
                                    <span></span>
                                </span>
                            </a>
                        </div> <!-- end of video-wrapper -->
                    </div> <!-- end of image-container -->
                    <!-- end of video preview -->                   
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div>
    
   
  <section id="hero" class="hero bg-gray-100">
        <div class="container">
        <div class="row  justify-content-center section-heading">
                        <div class="col-lg-8 col-xl-7 text-center wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
                        <h3 class="bg-primary-after after-50px pb-3 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationbasetitle')); ?></h3>                       
                      </div>
                    </div>
            <div class="row wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
            <div class="col-lg-12 col-xl-12">            
                <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationone')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationonefeatures'));
                                          echo $str; ?></p>
                  <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationtwo')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationtwofeatures'));
                                          echo $str; ?></p>
                <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationthree')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationthreefeatures'));
                                          echo $str; ?></p>                          
            </div>  
        </div>   

</div>
</section>
   
<?php echo $__env->make('site.layouts_ar.ask-for-quotation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
       
</main>
    
    <?php echo $__env->make('site.layouts_ar.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts_ar.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('site.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <body>
        <div class="wrapper">
        <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4"> <?php echo e(trans('solutions/byField/construction_and_contracting.solutiontitle')); ?> </h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active"> <?php echo e(trans('solutions/byField/construction_and_contracting.solutiontitle')); ?> </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  
    <div id="video" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <!-- Video Preview -->
                    <div class="image-container">
                        <div class="video-wrapper">
                            <a class="popup-youtube" href="https://www.youtube.com/watch?v=fLCjQJCekTs" data-effect="fadeIn">
                                
                                <span class="video-play-button">
                                    <span></span>
                                </span>
                            </a>
                        </div> <!-- end of video-wrapper -->
                    </div> <!-- end of image-container -->
                    <!-- end of video preview -->                   
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div>
    <div class="elementor-element elementor-element-6306f6c e-con-full e-flex e-con" data-id="6306f6c" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-element elementor-element-187e30e elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="187e30e" data-element_type="widget" data-widget_type="divider.default">
<div class="elementor-widget-container">
<div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
</div>
</div>
</div>
<div class="elementor-element elementor-element-5a75f04 e-n-tabs-mobile elementor-widget elementor-widget-n-tabs" data-id="5a75f04" data-element_type="widget" data-settings="{&quot;tabs_justify_horizontal&quot;:&quot;start&quot;,&quot;horizontal_scroll&quot;:&quot;disable&quot;}" data-widget_type="nested-tabs.default">
<div class="elementor-widget-container">
<div class="e-n-tabs">
<div class="e-n-tabs-heading" role="tablist" data-page-x="">
<div id="e-n-tabs-title-9481" class="e-n-tab-title e-normal e-active" aria-selected="true" data-tab="1" role="tab" tabindex="0" aria-controls="e-n-tab-content-9481" aria-expanded="true"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADmUlEQVR4nO2czU8TURTF+48NBD9WRhHdYOJag6hookbBPwPRpTEsXMiuBW2L8BK1gOIWHWDAtkxbQEA7b/3MHSBBM9j5vtOZc5KzpMyc37v3vXmdvlwOgiAIgiAIgiAIgiAIgiAIyuVymp5XcN53BoEHEcLPBxqAAKDzVjAA6BkEcH51Rgm5nSqfXZvpHgADxix7YCJkD2yUuwfAnVqFPTARsofrle4B8Gz3G3tgImTTPXUFgH6jpGatJntgImS/t1qq3ygnH8CLnzp7WCIiP9/9nmwAY+ZybGFop1xD1P/3ifklmQBGzWU1J1upBzAnW2rUA4TIAVBf5Gg7GhOAk+3IzZwQOgB6IKF1/u3agr0yoMkp7vBFAgCQ6d4pA8qCMnF6WAsdAEfYk/uGuldftFdYfauFwxsrDDma+3pTBaBsNdXd+oLqcSptAIi+vK//EKf3VgCIFsADc+n/kxsARBf+m19V1aMf9noAYJgDxszlzss7VEB0AK5tzjuGfrP2Ub21zFgGQaZXQRfWi44Apg6q7AEDgOQPObMt6Eb1g5ppowV5GgF+tgyeNr66/pyT7ludVheNov3w9nJvLdDI9bvVwV4BYdzI1EFV9R5tOQTxUO2TKloNAPAzkh6anwMDIA9uzKlyu/M3dKgA6W0rwoupJQGAj8m8bDXVyCmbcV5Mf//6YBMV4BWAOPLk/oa6v7X013a0V1NLy0QL4vQ7q2F/OeIU3NWYXhbLNAAht1WhveUI4FxMr0tmHkD+NwCwjf6i1VDDNedXCNGCQippzeN29LEfdZiE0YJkdAB69ULHZSgAyOgAjNQXY2uDqZuEtYAABjfdbUUAgAwfwK16RZXa7jbjAECGA+CSUbK3L17trcderalsQcIjmKRdFwBIAEAFBFHSSlygBfGHLxLszMwBIqEGAAkA7KNQoAI6l2bSLdLWgrgD1QCAP1QNFcAfrIYW1B0WmAPyAOA0CZ9Zm1ZXjLJ9fg79SDmNJ6MIl6Z7H99ZsbOgTCibyFdB/5reVqOf7XOHIWL2hH1UQaljlUYO4Nh0ikich3UIJs/Llnrs4keEsQM4PjGFOyARsb2EHzsAcprb0UTSD2wi03eyaZyYZ62mq57PDiCth/aN76z4WhazAKBXxLkDE1k+tpLWxNyBiZB92ceJiWwA6OQo7sBElo8uhvMAoCVkIKACdABgH4VaN1cABEEQBEEQBEEQBEEQBEFQLg36AxAGjnwwck4AAAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADmUlEQVR4nO2czU8TURTF+48NBD9WRhHdYOJag6hookbBPwPRpTEsXMiuBW2L8BK1gOIWHWDAtkxbQEA7b/3MHSBBM9j5vtOZc5KzpMyc37v3vXmdvlwOgiAIgiAIgiAIgiAIgiAIyuVymp5XcN53BoEHEcLPBxqAAKDzVjAA6BkEcH51Rgm5nSqfXZvpHgADxix7YCJkD2yUuwfAnVqFPTARsofrle4B8Gz3G3tgImTTPXUFgH6jpGatJntgImS/t1qq3ygnH8CLnzp7WCIiP9/9nmwAY+ZybGFop1xD1P/3ifklmQBGzWU1J1upBzAnW2rUA4TIAVBf5Gg7GhOAk+3IzZwQOgB6IKF1/u3agr0yoMkp7vBFAgCQ6d4pA8qCMnF6WAsdAEfYk/uGuldftFdYfauFwxsrDDma+3pTBaBsNdXd+oLqcSptAIi+vK//EKf3VgCIFsADc+n/kxsARBf+m19V1aMf9noAYJgDxszlzss7VEB0AK5tzjuGfrP2Ub21zFgGQaZXQRfWi44Apg6q7AEDgOQPObMt6Eb1g5ppowV5GgF+tgyeNr66/pyT7ludVheNov3w9nJvLdDI9bvVwV4BYdzI1EFV9R5tOQTxUO2TKloNAPAzkh6anwMDIA9uzKlyu/M3dKgA6W0rwoupJQGAj8m8bDXVyCmbcV5Mf//6YBMV4BWAOPLk/oa6v7X013a0V1NLy0QL4vQ7q2F/OeIU3NWYXhbLNAAht1WhveUI4FxMr0tmHkD+NwCwjf6i1VDDNedXCNGCQippzeN29LEfdZiE0YJkdAB69ULHZSgAyOgAjNQXY2uDqZuEtYAABjfdbUUAgAwfwK16RZXa7jbjAECGA+CSUbK3L17trcderalsQcIjmKRdFwBIAEAFBFHSSlygBfGHLxLszMwBIqEGAAkA7KNQoAI6l2bSLdLWgrgD1QCAP1QNFcAfrIYW1B0WmAPyAOA0CZ9Zm1ZXjLJ9fg79SDmNJ6MIl6Z7H99ZsbOgTCibyFdB/5reVqOf7XOHIWL2hH1UQaljlUYO4Nh0ikich3UIJs/Llnrs4keEsQM4PjGFOyARsb2EHzsAcprb0UTSD2wi03eyaZyYZ62mq57PDiCth/aN76z4WhazAKBXxLkDE1k+tpLWxNyBiZB92ceJiWwA6OQo7sBElo8uhvMAoCVkIKACdABgH4VaN1cABEEQBEEQBEEQBEEQBEFQLg36AxAGjnwwck4AAAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg></span> <span class="e-n-tab-title-text">Financials</span></div><div id="e-n-tabs-title-9482" class="e-n-tab-title e-normal" aria-selected="false" data-tab="2" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9482" aria-expanded="false"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADG0lEQVR4nO2ZzWoUQRSFS92KIor4g6+hC20UFNEH8BkUzEJBcZKu6/geulBQUEE3s9RHUIIgDk0QRBCZum1IMveOMQols1AwRGMmM32rp88HZxeSrvP1raomzgEAAAAAgBqjL10cZ6zXUzsUAiCg0SgmAAIajWICRijthbsz7uI2y9rCxmncLciifIUA2/IVAmzL16YLsC5fmywghfK1SQLmSj3qg3wn1jjM/NPzkWedefQvYtb/3K/npiA/8i+DY65uUJDbvxeRkATdqgDW6IOQqxPtGHdSkA/rBaQgQUcQQEE+Xopxl6sLFOTiRuWnIEFHEcAa855ccHXBB3n+LwGWEnREARTkmasD7Z4coiBrmwmwkqAjChheKNqsR1zq+FJm/6f8cYfHLGrjvyMtlzQx7vAsC9MqwLO8H14wXKrkZf+cRflU2QQM0z/rUoVYnky7AM/y2KVI+9PKAWJZnXoBQb61P/cPutTwLDetyqdKt6Bh5IZLDQr6zlIAVRjPUgwvHC4Vcu6fsS6Fqk4YnHapQEEfmRfCFU9B0IcuBVrLy/s9y1frQqjyyOrw4mHdv/NBr9uXoTYJei2F7eeteRFsEx+0a3oY573BKesSyDq9wUkzART0gXkBbD4F903Kv7W4uNezqHUBZB4ZtJaW9lUugEqdsV+8JpGc9WrlAjzrvPXCKZF41jeVlk+lnrBeNCWWuVKPVybAs96zXjCll7uVlN/uxd0UdCWBBce0ItIuyz0TF0CsV+wXq0kmZ708cQGe9bX1QindvNpyoVnBEWGzDiCgsH0BIaCAgGhdAiagsC8CW1DRzOAMKCAgNnoC8H3AtkVDAENAlsBWgAko7EtKagtynW7cTjZ9oG3+fjfmTPx5IaALAZiArZD6SHewBUFAB2dAxCGMLSjiFtSZwmuo9YdLNmWBgAICzN/CDBNgX0SGLci+jMwgOAMKCDB/CzNMgH0RWV22oEl/2NQtbtr+H1C3OAhgCMAEdKvbgmYOx7iduCljpuo+IOBPIMAYCDAGAoyBAGMgwBgIMAa3QgAAAAAAAAAAwI2Bn7IcK8AOemK0AAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADG0lEQVR4nO2ZzWoUQRSFS92KIor4g6+hC20UFNEH8BkUzEJBcZKu6/geulBQUEE3s9RHUIIgDk0QRBCZum1IMveOMQols1AwRGMmM32rp88HZxeSrvP1raomzgEAAAAAgBqjL10cZ6zXUzsUAiCg0SgmAAIajWICRijthbsz7uI2y9rCxmncLciifIUA2/IVAmzL16YLsC5fmywghfK1SQLmSj3qg3wn1jjM/NPzkWedefQvYtb/3K/npiA/8i+DY65uUJDbvxeRkATdqgDW6IOQqxPtGHdSkA/rBaQgQUcQQEE+Xopxl6sLFOTiRuWnIEFHEcAa855ccHXBB3n+LwGWEnREARTkmasD7Z4coiBrmwmwkqAjChheKNqsR1zq+FJm/6f8cYfHLGrjvyMtlzQx7vAsC9MqwLO8H14wXKrkZf+cRflU2QQM0z/rUoVYnky7AM/y2KVI+9PKAWJZnXoBQb61P/cPutTwLDetyqdKt6Bh5IZLDQr6zlIAVRjPUgwvHC4Vcu6fsS6Fqk4YnHapQEEfmRfCFU9B0IcuBVrLy/s9y1frQqjyyOrw4mHdv/NBr9uXoTYJei2F7eeteRFsEx+0a3oY573BKesSyDq9wUkzART0gXkBbD4F903Kv7W4uNezqHUBZB4ZtJaW9lUugEqdsV+8JpGc9WrlAjzrvPXCKZF41jeVlk+lnrBeNCWWuVKPVybAs96zXjCll7uVlN/uxd0UdCWBBce0ItIuyz0TF0CsV+wXq0kmZ708cQGe9bX1QindvNpyoVnBEWGzDiCgsH0BIaCAgGhdAiagsC8CW1DRzOAMKCAgNnoC8H3AtkVDAENAlsBWgAko7EtKagtynW7cTjZ9oG3+fjfmTPx5IaALAZiArZD6SHewBUFAB2dAxCGMLSjiFtSZwmuo9YdLNmWBgAICzN/CDBNgX0SGLci+jMwgOAMKCDB/CzNMgH0RWV22oEl/2NQtbtr+H1C3OAhgCMAEdKvbgmYOx7iduCljpuo+IOBPIMAYCDAGAoyBAGMgwBgIMAa3QgAAAAAAAAAAwI2Bn7IcK8AOemK0AAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg></span> <span class="e-n-tab-title-text">Property Management</span></div><div id="e-n-tabs-title-9483" class="e-n-tab-title e-normal" aria-selected="false" data-tab="3" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9483" aria-expanded="false"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAEgklEQVR4nO2bXWgcVRiGv2r9QQVtoexOjW0CFqHQG4UqOMcoQrCgBYV6ob2wRgPprsmGXrUIjRihrZUStLmoSoMKFb2x2UmamVYWrRdSf67UdmZnTHuhol4obRcpWl+ZbH62+d2YmTlzzn4PfLAsM8t33odzzu6eXSKGYRiGYRiGYRiGYRiGYRiGiCqnCGkqajRkB15hAY0xA0b6cdOR7eh7vQ3B7k24UlgPFJrxb/j4QBuCt5/Fq+E1lDSNIGDgabwcBp03gIVqzyZcGdiGPZQkSw3o991Lq4pkAYGNXJ+5cPC19cZjQGCjh5JCZwGBjfbAAU4fBrqaFg+/pwX4+j0gvMd3sIOSQFcBvoMNvoPLYZhhfXoQKKxbIPxm4LP+6rXjZeNSeRR3U9zoKiBwMDgV5kSdOQr0bwW675oOPpTy5pPAt+9fe+3ELHiH4kb2pluJQcBYCXf4Nv6aGehkucPAmcFqeSNzXzMuIHyNk7id4kRHAT/aaJsv1KWW7+BRihMdBfgOCpEJsNFFcSI78AoL0HAJcvBiVDMgfC2KE90EjJWQDWx8GJWAYBTHglPIUFzoJiBw8EVk4U9vxJ9TXOgmwK/58BVhXaS40HAGHIt8Btg4QnGhm4BSCSsDG0+UbXgRLD3nfBtbAKyguNBNwCSBg10RCChQ3Ogq4IKFVYGNP5ex7PwRfqVBcaOrgBDfRscy3n4+T0mgs4CQwMah/7H0HKak0FVAPoOWXAaP9zSh/eQBDPk2ri4a/CiuOvvxSXhPeG93Bs0UNzoJ2LsRN+YMdOQN/DDzwOWVzcDoa9WvomcGHz53og/o3Tz7oCZn4PucgRc6CDdQHOgioOtObMhn8c2ix47rgX2PAG89Va19D1efq+O8+KudTTGckOkgoHst7skZ+Lneg/dl1K8vZbGRBdSwK4Nbc1l4CYQ/uST5O9fgNooK1WdAzsDBpMKfkpDFfhZARD1NWJ0zcDlxAQYudq7DqoafAfksticdfo2EZ6QKiOpnKJVlLEF5A4MSBRxlAQbOSxOQxYWGFpDPoEVW+JMVySdlVQXk1mKHbAH5DJ5rWAF5iet/pPuAwgLOp0DAGMlCeBbmKmkNNRosQDIsQDIsQDIsQDKqC2gtlVaGRaqitABghXCtd03X+iB8TCqisgDhFnunenaLvaQiqgoQntU+s2fTK3aSaqgo4MFzw1tMr/j3LAGu9c9D5eJWUgnVBIjy0L2mZ12ar2/hWhXTte4nVVBJQOvZE82mW/xl3vCn94PfWsvH4/9zdiMJeOC70dWmZ52d6m+4c86qWY7KpjeyhtKOCgJax0o3C886fU1/iwioVvHL+34auoXSTOoFYO91wrU+ntVfXQLGZ8LxbfjoekoraRdgutahOfurU8DExjxAaSXtAnTrW5uBCEX71mYgQtG+tRmIULRvbQYiFO1bm4EIRfvWZiBC0b61GYhQtG9tBiIU7VubgQhF+657IKoWqYbswAQLkB+a4BkgPzjBS5AeRaohOzDR6AIYhmEYhmEYhmEYhmEYhmEoTfwHvaU27t9hPVYAAAAOZVhJZk1NACoAAAAIAAAAAAAAANJTkwAAAABJRU5ErkJggg=="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAEgklEQVR4nO2bXWgcVRiGv2r9QQVtoexOjW0CFqHQG4UqOMcoQrCgBYV6ob2wRgPprsmGXrUIjRihrZUStLmoSoMKFb2x2UmamVYWrRdSf67UdmZnTHuhol4obRcpWl+ZbH62+d2YmTlzzn4PfLAsM8t33odzzu6eXSKGYRiGYRiGYRiGYRiGYRiGiCqnCGkqajRkB15hAY0xA0b6cdOR7eh7vQ3B7k24UlgPFJrxb/j4QBuCt5/Fq+E1lDSNIGDgabwcBp03gIVqzyZcGdiGPZQkSw3o991Lq4pkAYGNXJ+5cPC19cZjQGCjh5JCZwGBjfbAAU4fBrqaFg+/pwX4+j0gvMd3sIOSQFcBvoMNvoPLYZhhfXoQKKxbIPxm4LP+6rXjZeNSeRR3U9zoKiBwMDgV5kSdOQr0bwW675oOPpTy5pPAt+9fe+3ELHiH4kb2pluJQcBYCXf4Nv6aGehkucPAmcFqeSNzXzMuIHyNk7id4kRHAT/aaJsv1KWW7+BRihMdBfgOCpEJsNFFcSI78AoL0HAJcvBiVDMgfC2KE90EjJWQDWx8GJWAYBTHglPIUFzoJiBw8EVk4U9vxJ9TXOgmwK/58BVhXaS40HAGHIt8Btg4QnGhm4BSCSsDG0+UbXgRLD3nfBtbAKyguNBNwCSBg10RCChQ3Ogq4IKFVYGNP5ex7PwRfqVBcaOrgBDfRscy3n4+T0mgs4CQwMah/7H0HKak0FVAPoOWXAaP9zSh/eQBDPk2ri4a/CiuOvvxSXhPeG93Bs0UNzoJ2LsRN+YMdOQN/DDzwOWVzcDoa9WvomcGHz53og/o3Tz7oCZn4PucgRc6CDdQHOgioOtObMhn8c2ix47rgX2PAG89Va19D1efq+O8+KudTTGckOkgoHst7skZ+Lneg/dl1K8vZbGRBdSwK4Nbc1l4CYQ/uST5O9fgNooK1WdAzsDBpMKfkpDFfhZARD1NWJ0zcDlxAQYudq7DqoafAfksticdfo2EZ6QKiOpnKJVlLEF5A4MSBRxlAQbOSxOQxYWGFpDPoEVW+JMVySdlVQXk1mKHbAH5DJ5rWAF5iet/pPuAwgLOp0DAGMlCeBbmKmkNNRosQDIsQDIsQDIsQDKqC2gtlVaGRaqitABghXCtd03X+iB8TCqisgDhFnunenaLvaQiqgoQntU+s2fTK3aSaqgo4MFzw1tMr/j3LAGu9c9D5eJWUgnVBIjy0L2mZ12ar2/hWhXTte4nVVBJQOvZE82mW/xl3vCn94PfWsvH4/9zdiMJeOC70dWmZ52d6m+4c86qWY7KpjeyhtKOCgJax0o3C886fU1/iwioVvHL+34auoXSTOoFYO91wrU+ntVfXQLGZ8LxbfjoekoraRdgutahOfurU8DExjxAaSXtAnTrW5uBCEX71mYgQtG+tRmIULRvbQYiFO1bm4EIRfvWZiBC0b61GYhQtG9tBiIU7VubgQhF+657IKoWqYbswAQLkB+a4BkgPzjBS5AeRaohOzDR6AIYhmEYhmEYhmEYhmEYhmEoTfwHvaU27t9hPVYAAAAOZVhJZk1NACoAAAAIAAAAAAAAANJTkwAAAABJRU5ErkJggg=="></image></svg></span> <span class="e-n-tab-title-text">Community Management</span></div><div id="e-n-tabs-title-9484" class="e-n-tab-title e-normal" aria-selected="false" data-tab="4" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9484" aria-expanded="false"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGuElEQVR4nO2aa2xURRTHT8HwjBgEeRik0BASfIAfFITOdI2IiMHED6IJkigUP6gYPmhiIj5IfHzyC34haiKJxiglIrszBcrdslgWCml5BtidKW3ljUp4dR99BMbM3Rab5d7du2y3d/bu/JKTLOTe2TnnP3POmdkCaDQajUaj0Wg0mqJFiDK3p+ApnjlbM3JBZNvDlS3+xyqjAYRa6LIqTtZiRtZjTjZgRmswJ2HMyEnEyUXEySa351z8CFGGOPkBM5rAnIpcDDH6vtvT9wQLItvuR4weylUAzMhct+fuGfCpHZMRJ+3OBSDdvvbQCLfn7Sl8Lf4ZmJF/nK1+2uz2fD2Hj2+fgjg97jD/b3R7vp6iMlq7BHF6xWkKquRkldtz9lAXRD/CjN7KpQD7TpPH3Z560eOLBsYjRusc5Pv0f8d9odB9bs9fvZXM6DrMAy84eVwetDCnF7Lmek7PWvxfQ+EdKiJe5NuHI0Z+6bdCa9AZOtbyYSHKzNMtJ92ZA0965Am4vH3TCMRJfZoA3wy6k6qy8NTWcXJFWgTwYiUPvNz/2bl8+xjM6BYHB6y/UTSwsO+951uNBxAn/3dH0cDrrjirYt+OGOVZ8re5GxYw+iRitMVBvt/ja6eTLFtURs71tqAVUOrgaO1zmNGrDruW84iRZJbA30KcfLFM1Ay1+86qSO0TiNO2kr8FRTywMlsOz8Vk/y/PAc6E90+HkkWIMszpVwMV+JSRA5Wtgaluu6Y8vvbQCMTIZger+d8cgv/toydqhkFJIT4fgjh5Z/5JWu70lfmn6yYgRvdnCWa3TE2y00nd75PbGZ6/WZKdjNmvc/pbX8AwIz/JTmYAOp2rsij3f08eyDCjZyx2SET+4gWlhmwFESd/Wq1cOyFkUBGj17KknLYqRmdZfafZ93P63Z3dwMjPi47WjYZi5GYIxseCsDpmgD9uQDQWhJg087MB/lgQqm8YMM7qXVnk5O+o2VII5vR7X2THNKedjkxLMj1lm7u5GzithmJE1MHouAHrYwZ0xIMgMpoBN2NB+EwEYFTf+yjqny378BwKYzfmNJi12DKy2fO/SMVDMCVuwKH0QCd2DxeJgxUp2z3cSohjyRBMS6UQcn1g20Yq087Xnj8MyQDGDbhstdIT+yaJ7gvvmSY/Wz1zNTjs2qunfhywwxLu1+mA1+lNO8fsUk2ycZroufShaYmmmSLeMEYk9oy667njDRViUfR3u1XckNNp1qLTKRS5LowBn4DM+ZaBPzBVdLUtFz2XPxGiY6dp8rPcCV2RxZZibWxakRZIclte894pzpxsQIx03mun4zkBzG7HouAm9k0U3effNYOdiwBX6keKl6K/9k22q4rXLk//zoxCMNI4r9U/EQYRVwWI7YK3rQLZFV2SCvTZatF59GnRFVlmWrJ5tkgcnGEKZJeyvjy8Vq7iDtxCFmf67ruEYHSL/HNBGGTcFUD2+VYCtC03Beg88WzmVtTCdoefSsp21OkcfJEdsoNa7Van47YALVZB7GRLU53PX2+KZGO5SIQfStnesSJePySjADeCQ1uhiMAuC9BhV4D7Ws906zq3WiSbZ9kKIMeEIgKrKIApQtMsM9h2QkiRbN69AUUEdlWAIPCMOb1+qEjsHX8nBSUPlJtpyawPLa/YvReBIgK7LMC2XIusLMyp+rDCLgVthSICuyxAtV2gZaspW85k8xzRFXnNtM4j88zW1NwBbKm1AEF4CwpIZTSAcjGlBZBXyvJW07IVjSy2PYjJQ1pi3wTL/H99JzwIBQQPcMBcFUAir5RzEqD9DZFsfMRu9X8MBQZ7TQB5nx8PwpG7UpC8cJMXb00zRc+lD0xLHqzIVB8Oi/1Q8JMs9poAkkQ9lMcNuHSv19HxIFxMGDAof+6BvShAvx9kmq12QvLwHNOsrqHjBhyVvyfAIIG9KkBfOooZ8KldYU4vuLEgrBuMtFMyAvQhO5mYAat6zwkReWLuPTXLz3/E6mFlobudkhZAZbAWQAtQVGDFV6znUxBWPGBaAK4FKChY8RWrdwDXAhQUrPiK1TuAawEKClZ8xeodwLUABQUrvmKV2wGqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+WN6g5ixcfLG9UdxIqPlzeqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+XMmslC9LfpEM7J0t8vtfFACxDWAhTTil2jd0BYC6BrgNA1YLpOQboLWqO7oLAuwhqNRqPRaDQajUaj0Wg0GvAK/wGuTH9FOzsE4wAAAA5lWElmTU0AKgAAAAgAAAAAAAAA0lOTAAAAAElFTkSuQmCC" transform="matrix(1 0 0 1 -1 1)"></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGuElEQVR4nO2aa2xURRTHT8HwjBgEeRik0BASfIAfFITOdI2IiMHED6IJkigUP6gYPmhiIj5IfHzyC34haiKJxiglIrszBcrdslgWCml5BtidKW3ljUp4dR99BMbM3Rab5d7du2y3d/bu/JKTLOTe2TnnP3POmdkCaDQajUaj0Wg0mqJFiDK3p+ApnjlbM3JBZNvDlS3+xyqjAYRa6LIqTtZiRtZjTjZgRmswJ2HMyEnEyUXEySa351z8CFGGOPkBM5rAnIpcDDH6vtvT9wQLItvuR4weylUAzMhct+fuGfCpHZMRJ+3OBSDdvvbQCLfn7Sl8Lf4ZmJF/nK1+2uz2fD2Hj2+fgjg97jD/b3R7vp6iMlq7BHF6xWkKquRkldtz9lAXRD/CjN7KpQD7TpPH3Z560eOLBsYjRusc5Pv0f8d9odB9bs9fvZXM6DrMAy84eVwetDCnF7Lmek7PWvxfQ+EdKiJe5NuHI0Z+6bdCa9AZOtbyYSHKzNMtJ92ZA0965Am4vH3TCMRJfZoA3wy6k6qy8NTWcXJFWgTwYiUPvNz/2bl8+xjM6BYHB6y/UTSwsO+951uNBxAn/3dH0cDrrjirYt+OGOVZ8re5GxYw+iRitMVBvt/ja6eTLFtURs71tqAVUOrgaO1zmNGrDruW84iRZJbA30KcfLFM1Ay1+86qSO0TiNO2kr8FRTywMlsOz8Vk/y/PAc6E90+HkkWIMszpVwMV+JSRA5Wtgaluu6Y8vvbQCMTIZger+d8cgv/toydqhkFJIT4fgjh5Z/5JWu70lfmn6yYgRvdnCWa3TE2y00nd75PbGZ6/WZKdjNmvc/pbX8AwIz/JTmYAOp2rsij3f08eyDCjZyx2SET+4gWlhmwFESd/Wq1cOyFkUBGj17KknLYqRmdZfafZ93P63Z3dwMjPi47WjYZi5GYIxseCsDpmgD9uQDQWhJg087MB/lgQqm8YMM7qXVnk5O+o2VII5vR7X2THNKedjkxLMj1lm7u5GzithmJE1MHouAHrYwZ0xIMgMpoBN2NB+EwEYFTf+yjqny378BwKYzfmNJi12DKy2fO/SMVDMCVuwKH0QCd2DxeJgxUp2z3cSohjyRBMS6UQcn1g20Yq087Xnj8MyQDGDbhstdIT+yaJ7gvvmSY/Wz1zNTjs2qunfhywwxLu1+mA1+lNO8fsUk2ycZroufShaYmmmSLeMEYk9oy667njDRViUfR3u1XckNNp1qLTKRS5LowBn4DM+ZaBPzBVdLUtFz2XPxGiY6dp8rPcCV2RxZZibWxakRZIclte894pzpxsQIx03mun4zkBzG7HouAm9k0U3effNYOdiwBX6keKl6K/9k22q4rXLk//zoxCMNI4r9U/EQYRVwWI7YK3rQLZFV2SCvTZatF59GnRFVlmWrJ5tkgcnGEKZJeyvjy8Vq7iDtxCFmf67ruEYHSL/HNBGGTcFUD2+VYCtC03Beg88WzmVtTCdoefSsp21OkcfJEdsoNa7Van47YALVZB7GRLU53PX2+KZGO5SIQfStnesSJePySjADeCQ1uhiMAuC9BhV4D7Ws906zq3WiSbZ9kKIMeEIgKrKIApQtMsM9h2QkiRbN69AUUEdlWAIPCMOb1+qEjsHX8nBSUPlJtpyawPLa/YvReBIgK7LMC2XIusLMyp+rDCLgVthSICuyxAtV2gZaspW85k8xzRFXnNtM4j88zW1NwBbKm1AEF4CwpIZTSAcjGlBZBXyvJW07IVjSy2PYjJQ1pi3wTL/H99JzwIBQQPcMBcFUAir5RzEqD9DZFsfMRu9X8MBQZ7TQB5nx8PwpG7UpC8cJMXb00zRc+lD0xLHqzIVB8Oi/1Q8JMs9poAkkQ9lMcNuHSv19HxIFxMGDAof+6BvShAvx9kmq12QvLwHNOsrqHjBhyVvyfAIIG9KkBfOooZ8KldYU4vuLEgrBuMtFMyAvQhO5mYAat6zwkReWLuPTXLz3/E6mFlobudkhZAZbAWQAtQVGDFV6znUxBWPGBaAK4FKChY8RWrdwDXAhQUrPiK1TuAawEKClZ8xeodwLUABQUrvmKV2wGqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+WN6g5ixcfLG9UdxIqPlzeqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+XMmslC9LfpEM7J0t8vtfFACxDWAhTTil2jd0BYC6BrgNA1YLpOQboLWqO7oLAuwhqNRqPRaDQajUaj0Wg0GvAK/wGuTH9FOzsE4wAAAA5lWElmTU0AKgAAAAgAAAAAAAAA0lOTAAAAAElFTkSuQmCC" transform="matrix(1 0 0 1 -1 1)"></image></svg></span> <span class="e-n-tab-title-text">Sales</span></div> </div>
<div class="e-n-tabs-content" role="tablist" aria-orientation="vertical">
<div class="e-n-tab-title e-collapse e-active" aria-selected="true" data-tab="1" role="tab" tabindex="0" aria-controls="e-n-tab-content-9481" aria-expanded="true" id="e-n-tabs-title-9481-accordion"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADmUlEQVR4nO2czU8TURTF+48NBD9WRhHdYOJag6hookbBPwPRpTEsXMiuBW2L8BK1gOIWHWDAtkxbQEA7b/3MHSBBM9j5vtOZc5KzpMyc37v3vXmdvlwOgiAIgiAIgiAIgiAIgiAIyuVymp5XcN53BoEHEcLPBxqAAKDzVjAA6BkEcH51Rgm5nSqfXZvpHgADxix7YCJkD2yUuwfAnVqFPTARsofrle4B8Gz3G3tgImTTPXUFgH6jpGatJntgImS/t1qq3ygnH8CLnzp7WCIiP9/9nmwAY+ZybGFop1xD1P/3ifklmQBGzWU1J1upBzAnW2rUA4TIAVBf5Gg7GhOAk+3IzZwQOgB6IKF1/u3agr0yoMkp7vBFAgCQ6d4pA8qCMnF6WAsdAEfYk/uGuldftFdYfauFwxsrDDma+3pTBaBsNdXd+oLqcSptAIi+vK//EKf3VgCIFsADc+n/kxsARBf+m19V1aMf9noAYJgDxszlzss7VEB0AK5tzjuGfrP2Ub21zFgGQaZXQRfWi44Apg6q7AEDgOQPObMt6Eb1g5ppowV5GgF+tgyeNr66/pyT7ludVheNov3w9nJvLdDI9bvVwV4BYdzI1EFV9R5tOQTxUO2TKloNAPAzkh6anwMDIA9uzKlyu/M3dKgA6W0rwoupJQGAj8m8bDXVyCmbcV5Mf//6YBMV4BWAOPLk/oa6v7X013a0V1NLy0QL4vQ7q2F/OeIU3NWYXhbLNAAht1WhveUI4FxMr0tmHkD+NwCwjf6i1VDDNedXCNGCQippzeN29LEfdZiE0YJkdAB69ULHZSgAyOgAjNQXY2uDqZuEtYAABjfdbUUAgAwfwK16RZXa7jbjAECGA+CSUbK3L17trcderalsQcIjmKRdFwBIAEAFBFHSSlygBfGHLxLszMwBIqEGAAkA7KNQoAI6l2bSLdLWgrgD1QCAP1QNFcAfrIYW1B0WmAPyAOA0CZ9Zm1ZXjLJ9fg79SDmNJ6MIl6Z7H99ZsbOgTCibyFdB/5reVqOf7XOHIWL2hH1UQaljlUYO4Nh0ikich3UIJs/Llnrs4keEsQM4PjGFOyARsb2EHzsAcprb0UTSD2wi03eyaZyYZ62mq57PDiCth/aN76z4WhazAKBXxLkDE1k+tpLWxNyBiZB92ceJiWwA6OQo7sBElo8uhvMAoCVkIKACdABgH4VaN1cABEEQBEEQBEEQBEEQBEFQLg36AxAGjnwwck4AAAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADmUlEQVR4nO2czU8TURTF+48NBD9WRhHdYOJag6hookbBPwPRpTEsXMiuBW2L8BK1gOIWHWDAtkxbQEA7b/3MHSBBM9j5vtOZc5KzpMyc37v3vXmdvlwOgiAIgiAIgiAIgiAIgiAIyuVymp5XcN53BoEHEcLPBxqAAKDzVjAA6BkEcH51Rgm5nSqfXZvpHgADxix7YCJkD2yUuwfAnVqFPTARsofrle4B8Gz3G3tgImTTPXUFgH6jpGatJntgImS/t1qq3ygnH8CLnzp7WCIiP9/9nmwAY+ZybGFop1xD1P/3ifklmQBGzWU1J1upBzAnW2rUA4TIAVBf5Gg7GhOAk+3IzZwQOgB6IKF1/u3agr0yoMkp7vBFAgCQ6d4pA8qCMnF6WAsdAEfYk/uGuldftFdYfauFwxsrDDma+3pTBaBsNdXd+oLqcSptAIi+vK//EKf3VgCIFsADc+n/kxsARBf+m19V1aMf9noAYJgDxszlzss7VEB0AK5tzjuGfrP2Ub21zFgGQaZXQRfWi44Apg6q7AEDgOQPObMt6Eb1g5ppowV5GgF+tgyeNr66/pyT7ludVheNov3w9nJvLdDI9bvVwV4BYdzI1EFV9R5tOQTxUO2TKloNAPAzkh6anwMDIA9uzKlyu/M3dKgA6W0rwoupJQGAj8m8bDXVyCmbcV5Mf//6YBMV4BWAOPLk/oa6v7X013a0V1NLy0QL4vQ7q2F/OeIU3NWYXhbLNAAht1WhveUI4FxMr0tmHkD+NwCwjf6i1VDDNedXCNGCQippzeN29LEfdZiE0YJkdAB69ULHZSgAyOgAjNQXY2uDqZuEtYAABjfdbUUAgAwfwK16RZXa7jbjAECGA+CSUbK3L17trcderalsQcIjmKRdFwBIAEAFBFHSSlygBfGHLxLszMwBIqEGAAkA7KNQoAI6l2bSLdLWgrgD1QCAP1QNFcAfrIYW1B0WmAPyAOA0CZ9Zm1ZXjLJ9fg79SDmNJ6MIl6Z7H99ZsbOgTCibyFdB/5reVqOf7XOHIWL2hH1UQaljlUYO4Nh0ikich3UIJs/Llnrs4keEsQM4PjGFOyARsb2EHzsAcprb0UTSD2wi03eyaZyYZ62mq57PDiCth/aN76z4WhazAKBXxLkDE1k+tpLWxNyBiZB92ceJiWwA6OQo7sBElo8uhvMAoCVkIKACdABgH4VaN1cABEEQBEEQBEEQBEEQBEFQLg36AxAGjnwwck4AAAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg></span> <span class="e-n-tab-title-text">Financials</span></div><div class="elementor-element elementor-element-c0af1f0 e-con-full e-flex e-con e-active" data-id="c0af1f0" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-964ef21 e-flex e-con-boxed e-con" data-id="964ef21" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-2f5d24f e-flex e-con-boxed e-con" data-id="2f5d24f" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-96d2465 e-con-full e-flex e-con" data-id="96d2465" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-67f6cbb elementor-widget elementor-widget-icon-box" data-id="67f6cbb" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
NetSuite Financials </span>
</h3>
<p class="elementor-icon-box-description">
Optimize finances with tools like general ledger, accounts payable/receivable, budgeting, forecasting, and accurate reporting for real estate organizations. </p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-028f8fe elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="028f8fe" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Accounting</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Advanced billing engine</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Planning and Budgeting</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Revenue Recognition</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Financial Reporting</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Fixed Assets</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Financial Consolidation</span>
</li>
</ul>
</div>
</div>
</div>
<div class="elementor-element elementor-element-a1a2f18 e-con-full e-flex e-con" data-id="a1a2f18" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-a0b9780 elementor-widget elementor-widget-image" data-id="a0b9780" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<img decoding="async" loading="lazy" width="1008" height="593" src="https://www.azdan.com/wp-content/uploads/2023/07/financial-management.png" class="attachment-large size-large wp-image-18389" alt="financial managemnt" srcset="https://www.azdan.com/wp-content/uploads/2023/07/financial-management.png 1008w, https://www.azdan.com/wp-content/uploads/2023/07/financial-management-300x176.png 300w, https://www.azdan.com/wp-content/uploads/2023/07/financial-management-768x452.png 768w" sizes="(max-width: 1008px) 100vw, 1008px"> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="e-n-tab-title e-collapse" aria-selected="false" data-tab="2" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9482" aria-expanded="false" id="e-n-tabs-title-9482-accordion"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADG0lEQVR4nO2ZzWoUQRSFS92KIor4g6+hC20UFNEH8BkUzEJBcZKu6/geulBQUEE3s9RHUIIgDk0QRBCZum1IMveOMQols1AwRGMmM32rp88HZxeSrvP1raomzgEAAAAAgBqjL10cZ6zXUzsUAiCg0SgmAAIajWICRijthbsz7uI2y9rCxmncLciifIUA2/IVAmzL16YLsC5fmywghfK1SQLmSj3qg3wn1jjM/NPzkWedefQvYtb/3K/npiA/8i+DY65uUJDbvxeRkATdqgDW6IOQqxPtGHdSkA/rBaQgQUcQQEE+Xopxl6sLFOTiRuWnIEFHEcAa855ccHXBB3n+LwGWEnREARTkmasD7Z4coiBrmwmwkqAjChheKNqsR1zq+FJm/6f8cYfHLGrjvyMtlzQx7vAsC9MqwLO8H14wXKrkZf+cRflU2QQM0z/rUoVYnky7AM/y2KVI+9PKAWJZnXoBQb61P/cPutTwLDetyqdKt6Bh5IZLDQr6zlIAVRjPUgwvHC4Vcu6fsS6Fqk4YnHapQEEfmRfCFU9B0IcuBVrLy/s9y1frQqjyyOrw4mHdv/NBr9uXoTYJei2F7eeteRFsEx+0a3oY573BKesSyDq9wUkzART0gXkBbD4F903Kv7W4uNezqHUBZB4ZtJaW9lUugEqdsV+8JpGc9WrlAjzrvPXCKZF41jeVlk+lnrBeNCWWuVKPVybAs96zXjCll7uVlN/uxd0UdCWBBce0ItIuyz0TF0CsV+wXq0kmZ708cQGe9bX1QindvNpyoVnBEWGzDiCgsH0BIaCAgGhdAiagsC8CW1DRzOAMKCAgNnoC8H3AtkVDAENAlsBWgAko7EtKagtynW7cTjZ9oG3+fjfmTPx5IaALAZiArZD6SHewBUFAB2dAxCGMLSjiFtSZwmuo9YdLNmWBgAICzN/CDBNgX0SGLci+jMwgOAMKCDB/CzNMgH0RWV22oEl/2NQtbtr+H1C3OAhgCMAEdKvbgmYOx7iduCljpuo+IOBPIMAYCDAGAoyBAGMgwBgIMAa3QgAAAAAAAAAAwI2Bn7IcK8AOemK0AAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAADG0lEQVR4nO2ZzWoUQRSFS92KIor4g6+hC20UFNEH8BkUzEJBcZKu6/geulBQUEE3s9RHUIIgDk0QRBCZum1IMveOMQols1AwRGMmM32rp88HZxeSrvP1raomzgEAAAAAgBqjL10cZ6zXUzsUAiCg0SgmAAIajWICRijthbsz7uI2y9rCxmncLciifIUA2/IVAmzL16YLsC5fmywghfK1SQLmSj3qg3wn1jjM/NPzkWedefQvYtb/3K/npiA/8i+DY65uUJDbvxeRkATdqgDW6IOQqxPtGHdSkA/rBaQgQUcQQEE+Xopxl6sLFOTiRuWnIEFHEcAa855ccHXBB3n+LwGWEnREARTkmasD7Z4coiBrmwmwkqAjChheKNqsR1zq+FJm/6f8cYfHLGrjvyMtlzQx7vAsC9MqwLO8H14wXKrkZf+cRflU2QQM0z/rUoVYnky7AM/y2KVI+9PKAWJZnXoBQb61P/cPutTwLDetyqdKt6Bh5IZLDQr6zlIAVRjPUgwvHC4Vcu6fsS6Fqk4YnHapQEEfmRfCFU9B0IcuBVrLy/s9y1frQqjyyOrw4mHdv/NBr9uXoTYJei2F7eeteRFsEx+0a3oY573BKesSyDq9wUkzART0gXkBbD4F903Kv7W4uNezqHUBZB4ZtJaW9lUugEqdsV+8JpGc9WrlAjzrvPXCKZF41jeVlk+lnrBeNCWWuVKPVybAs96zXjCll7uVlN/uxd0UdCWBBce0ItIuyz0TF0CsV+wXq0kmZ708cQGe9bX1QindvNpyoVnBEWGzDiCgsH0BIaCAgGhdAiagsC8CW1DRzOAMKCAgNnoC8H3AtkVDAENAlsBWgAko7EtKagtynW7cTjZ9oG3+fjfmTPx5IaALAZiArZD6SHewBUFAB2dAxCGMLSjiFtSZwmuo9YdLNmWBgAICzN/CDBNgX0SGLci+jMwgOAMKCDB/CzNMgH0RWV22oEl/2NQtbtr+H1C3OAhgCMAEdKvbgmYOx7iduCljpuo+IOBPIMAYCDAGAoyBAGMgwBgIMAa3QgAAAAAAAAAAwI2Bn7IcK8AOemK0AAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="></image></svg></span> <span class="e-n-tab-title-text">Property Management</span></div><div class="elementor-element elementor-element-26e0bc4 e-con-full e-flex e-con" data-id="26e0bc4" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}" hidden="hidden">
<div class="elementor-element elementor-element-1905693 e-flex e-con-boxed e-con" data-id="1905693" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-c8419de e-flex e-con-boxed e-con" data-id="c8419de" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-865ec6a e-con-full e-flex e-con" data-id="865ec6a" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-3b7932e elementor-widget elementor-widget-icon-box" data-id="3b7932e" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Property Management </span>
</h3>
<p class="elementor-icon-box-description">
Streamline property, lease, and tenant management with lease administration, billing, maintenance tracking, and performance analysis. </p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-f412ae9 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="f412ae9" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Units Maintenance and Management.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text"> Utilities Management. </span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Manage the complete asset lifecycle.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">MEP &amp; Civil Inventory Management.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Technical Library.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Manage projects with individual units. </span>
</li>
</ul>
</div>
</div>
</div>
<div class="elementor-element elementor-element-b29a58f e-con-full e-flex e-con" data-id="b29a58f" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-c12db90 elementor-widget elementor-widget-image" data-id="c12db90" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<img decoding="async" loading="lazy" width="1008" height="593" src="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Property_Management.png" class="attachment-large size-large wp-image-18393" alt="ERP for Real Estate 1" srcset="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Property_Management.png 1008w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Property_Management-300x176.png 300w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Property_Management-768x452.png 768w" sizes="(max-width: 1008px) 100vw, 1008px"> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="e-n-tab-title e-collapse" aria-selected="false" data-tab="3" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9483" aria-expanded="false" id="e-n-tabs-title-9483-accordion"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAEgklEQVR4nO2bXWgcVRiGv2r9QQVtoexOjW0CFqHQG4UqOMcoQrCgBYV6ob2wRgPprsmGXrUIjRihrZUStLmoSoMKFb2x2UmamVYWrRdSf67UdmZnTHuhol4obRcpWl+ZbH62+d2YmTlzzn4PfLAsM8t33odzzu6eXSKGYRiGYRiGYRiGYRiGYRiGiCqnCGkqajRkB15hAY0xA0b6cdOR7eh7vQ3B7k24UlgPFJrxb/j4QBuCt5/Fq+E1lDSNIGDgabwcBp03gIVqzyZcGdiGPZQkSw3o991Lq4pkAYGNXJ+5cPC19cZjQGCjh5JCZwGBjfbAAU4fBrqaFg+/pwX4+j0gvMd3sIOSQFcBvoMNvoPLYZhhfXoQKKxbIPxm4LP+6rXjZeNSeRR3U9zoKiBwMDgV5kSdOQr0bwW675oOPpTy5pPAt+9fe+3ELHiH4kb2pluJQcBYCXf4Nv6aGehkucPAmcFqeSNzXzMuIHyNk7id4kRHAT/aaJsv1KWW7+BRihMdBfgOCpEJsNFFcSI78AoL0HAJcvBiVDMgfC2KE90EjJWQDWx8GJWAYBTHglPIUFzoJiBw8EVk4U9vxJ9TXOgmwK/58BVhXaS40HAGHIt8Btg4QnGhm4BSCSsDG0+UbXgRLD3nfBtbAKyguNBNwCSBg10RCChQ3Ogq4IKFVYGNP5ex7PwRfqVBcaOrgBDfRscy3n4+T0mgs4CQwMah/7H0HKak0FVAPoOWXAaP9zSh/eQBDPk2ri4a/CiuOvvxSXhPeG93Bs0UNzoJ2LsRN+YMdOQN/DDzwOWVzcDoa9WvomcGHz53og/o3Tz7oCZn4PucgRc6CDdQHOgioOtObMhn8c2ix47rgX2PAG89Va19D1efq+O8+KudTTGckOkgoHst7skZ+Lneg/dl1K8vZbGRBdSwK4Nbc1l4CYQ/uST5O9fgNooK1WdAzsDBpMKfkpDFfhZARD1NWJ0zcDlxAQYudq7DqoafAfksticdfo2EZ6QKiOpnKJVlLEF5A4MSBRxlAQbOSxOQxYWGFpDPoEVW+JMVySdlVQXk1mKHbAH5DJ5rWAF5iet/pPuAwgLOp0DAGMlCeBbmKmkNNRosQDIsQDIsQDIsQDKqC2gtlVaGRaqitABghXCtd03X+iB8TCqisgDhFnunenaLvaQiqgoQntU+s2fTK3aSaqgo4MFzw1tMr/j3LAGu9c9D5eJWUgnVBIjy0L2mZ12ar2/hWhXTte4nVVBJQOvZE82mW/xl3vCn94PfWsvH4/9zdiMJeOC70dWmZ52d6m+4c86qWY7KpjeyhtKOCgJax0o3C886fU1/iwioVvHL+34auoXSTOoFYO91wrU+ntVfXQLGZ8LxbfjoekoraRdgutahOfurU8DExjxAaSXtAnTrW5uBCEX71mYgQtG+tRmIULRvbQYiFO1bm4EIRfvWZiBC0b61GYhQtG9tBiIU7VubgQhF+657IKoWqYbswAQLkB+a4BkgPzjBS5AeRaohOzDR6AIYhmEYhmEYhmEYhmEYhmEoTfwHvaU27t9hPVYAAAAOZVhJZk1NACoAAAAIAAAAAAAAANJTkwAAAABJRU5ErkJggg=="></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAEgklEQVR4nO2bXWgcVRiGv2r9QQVtoexOjW0CFqHQG4UqOMcoQrCgBYV6ob2wRgPprsmGXrUIjRihrZUStLmoSoMKFb2x2UmamVYWrRdSf67UdmZnTHuhol4obRcpWl+ZbH62+d2YmTlzzn4PfLAsM8t33odzzu6eXSKGYRiGYRiGYRiGYRiGYRiGiCqnCGkqajRkB15hAY0xA0b6cdOR7eh7vQ3B7k24UlgPFJrxb/j4QBuCt5/Fq+E1lDSNIGDgabwcBp03gIVqzyZcGdiGPZQkSw3o991Lq4pkAYGNXJ+5cPC19cZjQGCjh5JCZwGBjfbAAU4fBrqaFg+/pwX4+j0gvMd3sIOSQFcBvoMNvoPLYZhhfXoQKKxbIPxm4LP+6rXjZeNSeRR3U9zoKiBwMDgV5kSdOQr0bwW675oOPpTy5pPAt+9fe+3ELHiH4kb2pluJQcBYCXf4Nv6aGehkucPAmcFqeSNzXzMuIHyNk7id4kRHAT/aaJsv1KWW7+BRihMdBfgOCpEJsNFFcSI78AoL0HAJcvBiVDMgfC2KE90EjJWQDWx8GJWAYBTHglPIUFzoJiBw8EVk4U9vxJ9TXOgmwK/58BVhXaS40HAGHIt8Btg4QnGhm4BSCSsDG0+UbXgRLD3nfBtbAKyguNBNwCSBg10RCChQ3Ogq4IKFVYGNP5ex7PwRfqVBcaOrgBDfRscy3n4+T0mgs4CQwMah/7H0HKak0FVAPoOWXAaP9zSh/eQBDPk2ri4a/CiuOvvxSXhPeG93Bs0UNzoJ2LsRN+YMdOQN/DDzwOWVzcDoa9WvomcGHz53og/o3Tz7oCZn4PucgRc6CDdQHOgioOtObMhn8c2ix47rgX2PAG89Va19D1efq+O8+KudTTGckOkgoHst7skZ+Lneg/dl1K8vZbGRBdSwK4Nbc1l4CYQ/uST5O9fgNooK1WdAzsDBpMKfkpDFfhZARD1NWJ0zcDlxAQYudq7DqoafAfksticdfo2EZ6QKiOpnKJVlLEF5A4MSBRxlAQbOSxOQxYWGFpDPoEVW+JMVySdlVQXk1mKHbAH5DJ5rWAF5iet/pPuAwgLOp0DAGMlCeBbmKmkNNRosQDIsQDIsQDIsQDKqC2gtlVaGRaqitABghXCtd03X+iB8TCqisgDhFnunenaLvaQiqgoQntU+s2fTK3aSaqgo4MFzw1tMr/j3LAGu9c9D5eJWUgnVBIjy0L2mZ12ar2/hWhXTte4nVVBJQOvZE82mW/xl3vCn94PfWsvH4/9zdiMJeOC70dWmZ52d6m+4c86qWY7KpjeyhtKOCgJax0o3C886fU1/iwioVvHL+34auoXSTOoFYO91wrU+ntVfXQLGZ8LxbfjoekoraRdgutahOfurU8DExjxAaSXtAnTrW5uBCEX71mYgQtG+tRmIULRvbQYiFO1bm4EIRfvWZiBC0b61GYhQtG9tBiIU7VubgQhF+657IKoWqYbswAQLkB+a4BkgPzjBS5AeRaohOzDR6AIYhmEYhmEYhmEYhmEYhmEoTfwHvaU27t9hPVYAAAAOZVhJZk1NACoAAAAIAAAAAAAAANJTkwAAAABJRU5ErkJggg=="></image></svg></span> <span class="e-n-tab-title-text">Community Management</span></div><div class="elementor-element elementor-element-8fc267f e-con-full e-flex e-con" data-id="8fc267f" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}" hidden="hidden">
<div class="elementor-element elementor-element-61ff4e5 e-flex e-con-boxed e-con" data-id="61ff4e5" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-55b4d77 e-flex e-con-boxed e-con" data-id="55b4d77" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-e96fe1b e-con-full e-flex e-con" data-id="e96fe1b" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-06c6597 elementor-widget elementor-widget-icon-box" data-id="06c6597" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Community Management </span>
</h3>
<p class="elementor-icon-box-description">
Efficiently manage homeowner associations with NetSuite's community management features. Streamline tasks, enhance communication, and foster community engagement. </p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-374391b elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="374391b" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Tenants and Owner’s Management</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text"> Address tenant and maintenance complaints</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Resolve any incoming ticket.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Notification for payments contracts rent.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Integration with System can send bulk messages.</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Reporting and Analytics</span>
</li>
</ul>
</div>
</div>
</div>
<div class="elementor-element elementor-element-d70b4fc e-con-full e-flex e-con" data-id="d70b4fc" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-e092f5a elementor-widget elementor-widget-image" data-id="e092f5a" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<img decoding="async" loading="lazy" width="1008" height="593" src="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_community_management-1.png" class="attachment-large size-large wp-image-18402" alt="ERP for Real Estate 2" srcset="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_community_management-1.png 1008w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_community_management-1-300x176.png 300w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_community_management-1-768x452.png 768w" sizes="(max-width: 1008px) 100vw, 1008px"> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="e-n-tab-title e-collapse" aria-selected="false" data-tab="4" role="tab" tabindex="-1" aria-controls="e-n-tab-content-9484" aria-expanded="false" id="e-n-tabs-title-9484-accordion"> <span class="e-n-tab-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGuElEQVR4nO2aa2xURRTHT8HwjBgEeRik0BASfIAfFITOdI2IiMHED6IJkigUP6gYPmhiIj5IfHzyC34haiKJxiglIrszBcrdslgWCml5BtidKW3ljUp4dR99BMbM3Rab5d7du2y3d/bu/JKTLOTe2TnnP3POmdkCaDQajUaj0Wg0mqJFiDK3p+ApnjlbM3JBZNvDlS3+xyqjAYRa6LIqTtZiRtZjTjZgRmswJ2HMyEnEyUXEySa351z8CFGGOPkBM5rAnIpcDDH6vtvT9wQLItvuR4weylUAzMhct+fuGfCpHZMRJ+3OBSDdvvbQCLfn7Sl8Lf4ZmJF/nK1+2uz2fD2Hj2+fgjg97jD/b3R7vp6iMlq7BHF6xWkKquRkldtz9lAXRD/CjN7KpQD7TpPH3Z560eOLBsYjRusc5Pv0f8d9odB9bs9fvZXM6DrMAy84eVwetDCnF7Lmek7PWvxfQ+EdKiJe5NuHI0Z+6bdCa9AZOtbyYSHKzNMtJ92ZA0965Am4vH3TCMRJfZoA3wy6k6qy8NTWcXJFWgTwYiUPvNz/2bl8+xjM6BYHB6y/UTSwsO+951uNBxAn/3dH0cDrrjirYt+OGOVZ8re5GxYw+iRitMVBvt/ja6eTLFtURs71tqAVUOrgaO1zmNGrDruW84iRZJbA30KcfLFM1Ay1+86qSO0TiNO2kr8FRTywMlsOz8Vk/y/PAc6E90+HkkWIMszpVwMV+JSRA5Wtgaluu6Y8vvbQCMTIZger+d8cgv/toydqhkFJIT4fgjh5Z/5JWu70lfmn6yYgRvdnCWa3TE2y00nd75PbGZ6/WZKdjNmvc/pbX8AwIz/JTmYAOp2rsij3f08eyDCjZyx2SET+4gWlhmwFESd/Wq1cOyFkUBGj17KknLYqRmdZfafZ93P63Z3dwMjPi47WjYZi5GYIxseCsDpmgD9uQDQWhJg087MB/lgQqm8YMM7qXVnk5O+o2VII5vR7X2THNKedjkxLMj1lm7u5GzithmJE1MHouAHrYwZ0xIMgMpoBN2NB+EwEYFTf+yjqny378BwKYzfmNJi12DKy2fO/SMVDMCVuwKH0QCd2DxeJgxUp2z3cSohjyRBMS6UQcn1g20Yq087Xnj8MyQDGDbhstdIT+yaJ7gvvmSY/Wz1zNTjs2qunfhywwxLu1+mA1+lNO8fsUk2ycZroufShaYmmmSLeMEYk9oy667njDRViUfR3u1XckNNp1qLTKRS5LowBn4DM+ZaBPzBVdLUtFz2XPxGiY6dp8rPcCV2RxZZibWxakRZIclte894pzpxsQIx03mun4zkBzG7HouAm9k0U3effNYOdiwBX6keKl6K/9k22q4rXLk//zoxCMNI4r9U/EQYRVwWI7YK3rQLZFV2SCvTZatF59GnRFVlmWrJ5tkgcnGEKZJeyvjy8Vq7iDtxCFmf67ruEYHSL/HNBGGTcFUD2+VYCtC03Beg88WzmVtTCdoefSsp21OkcfJEdsoNa7Van47YALVZB7GRLU53PX2+KZGO5SIQfStnesSJePySjADeCQ1uhiMAuC9BhV4D7Ws906zq3WiSbZ9kKIMeEIgKrKIApQtMsM9h2QkiRbN69AUUEdlWAIPCMOb1+qEjsHX8nBSUPlJtpyawPLa/YvReBIgK7LMC2XIusLMyp+rDCLgVthSICuyxAtV2gZaspW85k8xzRFXnNtM4j88zW1NwBbKm1AEF4CwpIZTSAcjGlBZBXyvJW07IVjSy2PYjJQ1pi3wTL/H99JzwIBQQPcMBcFUAir5RzEqD9DZFsfMRu9X8MBQZ7TQB5nx8PwpG7UpC8cJMXb00zRc+lD0xLHqzIVB8Oi/1Q8JMs9poAkkQ9lMcNuHSv19HxIFxMGDAof+6BvShAvx9kmq12QvLwHNOsrqHjBhyVvyfAIIG9KkBfOooZ8KldYU4vuLEgrBuMtFMyAvQhO5mYAat6zwkReWLuPTXLz3/E6mFlobudkhZAZbAWQAtQVGDFV6znUxBWPGBaAK4FKChY8RWrdwDXAhQUrPiK1TuAawEKClZ8xeodwLUABQUrvmKV2wGqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+WN6g5ixcfLG9UdxIqPlzeqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+XMmslC9LfpEM7J0t8vtfFACxDWAhTTil2jd0BYC6BrgNA1YLpOQboLWqO7oLAuwhqNRqPRaDQajUaj0Wg0GvAK/wGuTH9FOzsE4wAAAA5lWElmTU0AKgAAAAgAAAAAAAAA0lOTAAAAAElFTkSuQmCC" transform="matrix(1 0 0 1 -1 1)"></image></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><image style="overflow:visible;" width="96" height="96" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGuElEQVR4nO2aa2xURRTHT8HwjBgEeRik0BASfIAfFITOdI2IiMHED6IJkigUP6gYPmhiIj5IfHzyC34haiKJxiglIrszBcrdslgWCml5BtidKW3ljUp4dR99BMbM3Rab5d7du2y3d/bu/JKTLOTe2TnnP3POmdkCaDQajUaj0Wg0mqJFiDK3p+ApnjlbM3JBZNvDlS3+xyqjAYRa6LIqTtZiRtZjTjZgRmswJ2HMyEnEyUXEySa351z8CFGGOPkBM5rAnIpcDDH6vtvT9wQLItvuR4weylUAzMhct+fuGfCpHZMRJ+3OBSDdvvbQCLfn7Sl8Lf4ZmJF/nK1+2uz2fD2Hj2+fgjg97jD/b3R7vp6iMlq7BHF6xWkKquRkldtz9lAXRD/CjN7KpQD7TpPH3Z560eOLBsYjRusc5Pv0f8d9odB9bs9fvZXM6DrMAy84eVwetDCnF7Lmek7PWvxfQ+EdKiJe5NuHI0Z+6bdCa9AZOtbyYSHKzNMtJ92ZA0965Am4vH3TCMRJfZoA3wy6k6qy8NTWcXJFWgTwYiUPvNz/2bl8+xjM6BYHB6y/UTSwsO+951uNBxAn/3dH0cDrrjirYt+OGOVZ8re5GxYw+iRitMVBvt/ja6eTLFtURs71tqAVUOrgaO1zmNGrDruW84iRZJbA30KcfLFM1Ay1+86qSO0TiNO2kr8FRTywMlsOz8Vk/y/PAc6E90+HkkWIMszpVwMV+JSRA5Wtgaluu6Y8vvbQCMTIZger+d8cgv/toydqhkFJIT4fgjh5Z/5JWu70lfmn6yYgRvdnCWa3TE2y00nd75PbGZ6/WZKdjNmvc/pbX8AwIz/JTmYAOp2rsij3f08eyDCjZyx2SET+4gWlhmwFESd/Wq1cOyFkUBGj17KknLYqRmdZfafZ93P63Z3dwMjPi47WjYZi5GYIxseCsDpmgD9uQDQWhJg087MB/lgQqm8YMM7qXVnk5O+o2VII5vR7X2THNKedjkxLMj1lm7u5GzithmJE1MHouAHrYwZ0xIMgMpoBN2NB+EwEYFTf+yjqny378BwKYzfmNJi12DKy2fO/SMVDMCVuwKH0QCd2DxeJgxUp2z3cSohjyRBMS6UQcn1g20Yq087Xnj8MyQDGDbhstdIT+yaJ7gvvmSY/Wz1zNTjs2qunfhywwxLu1+mA1+lNO8fsUk2ycZroufShaYmmmSLeMEYk9oy667njDRViUfR3u1XckNNp1qLTKRS5LowBn4DM+ZaBPzBVdLUtFz2XPxGiY6dp8rPcCV2RxZZibWxakRZIclte894pzpxsQIx03mun4zkBzG7HouAm9k0U3effNYOdiwBX6keKl6K/9k22q4rXLk//zoxCMNI4r9U/EQYRVwWI7YK3rQLZFV2SCvTZatF59GnRFVlmWrJ5tkgcnGEKZJeyvjy8Vq7iDtxCFmf67ruEYHSL/HNBGGTcFUD2+VYCtC03Beg88WzmVtTCdoefSsp21OkcfJEdsoNa7Van47YALVZB7GRLU53PX2+KZGO5SIQfStnesSJePySjADeCQ1uhiMAuC9BhV4D7Ws906zq3WiSbZ9kKIMeEIgKrKIApQtMsM9h2QkiRbN69AUUEdlWAIPCMOb1+qEjsHX8nBSUPlJtpyawPLa/YvReBIgK7LMC2XIusLMyp+rDCLgVthSICuyxAtV2gZaspW85k8xzRFXnNtM4j88zW1NwBbKm1AEF4CwpIZTSAcjGlBZBXyvJW07IVjSy2PYjJQ1pi3wTL/H99JzwIBQQPcMBcFUAir5RzEqD9DZFsfMRu9X8MBQZ7TQB5nx8PwpG7UpC8cJMXb00zRc+lD0xLHqzIVB8Oi/1Q8JMs9poAkkQ9lMcNuHSv19HxIFxMGDAof+6BvShAvx9kmq12QvLwHNOsrqHjBhyVvyfAIIG9KkBfOooZ8KldYU4vuLEgrBuMtFMyAvQhO5mYAat6zwkReWLuPTXLz3/E6mFlobudkhZAZbAWQAtQVGDFV6znUxBWPGBaAK4FKChY8RWrdwDXAhQUrPiK1TuAawEKClZ8xeodwLUABQUrvmKV2wGqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+WN6g5ixcfLG9UdxIqPlzeqO4gVHy9vVHcQKz5e3qjuIFZ8vLxR3UGs+Hh5o7qDWPHx8kZ1B7Hi4+XMmslC9LfpEM7J0t8vtfFACxDWAhTTil2jd0BYC6BrgNA1YLpOQboLWqO7oLAuwhqNRqPRaDQajUaj0Wg0GvAK/wGuTH9FOzsE4wAAAA5lWElmTU0AKgAAAAgAAAAAAAAA0lOTAAAAAElFTkSuQmCC" transform="matrix(1 0 0 1 -1 1)"></image></svg></span> <span class="e-n-tab-title-text">Sales</span></div><div class="elementor-element elementor-element-17b5d3e e-con-full e-flex e-con" data-id="17b5d3e" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}" hidden="hidden">
<div class="elementor-element elementor-element-8f5d655 e-flex e-con-boxed e-con" data-id="8f5d655" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-3ca8e54 e-flex e-con-boxed e-con" data-id="3ca8e54" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;boxed&quot;}">
<div class="e-con-inner">
<div class="elementor-element elementor-element-339a990 e-con-full e-flex e-con" data-id="339a990" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-678240d elementor-widget elementor-widget-icon-box" data-id="678240d" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Salesforce Automation </span>
</h3>
<p class="elementor-icon-box-description">
NetSuite Salesforce Automation provides a comprehensive erp for real estate to manage their sales operations. It includes: </p>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-c89df13 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c89df13" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Efficient lead management</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Integrated contact management</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Trade-in management tools</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Automated sales processes</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Task and activity tracking</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Sales performance analytics</span>
</li>
<li class="elementor-icon-list-item">
<span class="elementor-icon-list-icon">
<i aria-hidden="true" class="far fa-check-circle"></i> </span>
<span class="elementor-icon-list-text">Opportunity management</span>
</li>
</ul>
</div>
</div>
</div>
<div class="elementor-element elementor-element-d970f4e e-con-full e-flex e-con" data-id="d970f4e" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-5653868 elementor-widget elementor-widget-image" data-id="5653868" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<img decoding="async" loading="lazy" width="921" height="479" src="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Presentation_Master-2.jpg" class="attachment-large size-large wp-image-18408" alt="ERP for Real Estate 3" srcset="https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Presentation_Master-2.jpg 921w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Presentation_Master-2-300x156.jpg 300w, https://www.azdan.com/wp-content/uploads/2023/07/NetSuite_Presentation_Master-2-768x399.jpg 768w" sizes="(max-width: 921px) 100vw, 921px"> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
    <section id="hero" class="hero d-flex bg-gray-100">
        <div class="container">
        <div class="row  justify-content-center section-heading">
                        <div class="col-lg-8 col-xl-7 text-center wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
                        <h3 class="bg-primary-after after-50px pb-3 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationbasetitle')); ?></h3>                       
                      </div>
                    </div>
            <div class="row wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
            <div class="col-lg-12 col-xl-12">           
                <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationone')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationonefeatures'));
                                          echo $str; ?></p>
                  <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationtwo')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationtwofeatures'));
                                          echo $str; ?></p>
                <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/construction_and_contracting.solutionclassificationthree')); ?></h4>
                <p class="lead"><?php $str = htmlspecialchars_decode(trans('solutions/byField/construction_and_contracting.solutionclassificationthreefeatures'));
                                          echo $str; ?></p>                          
            </div>
        </div>    

</div>
</section>
<?php echo $__env->make('site.layouts.ask-for-quotation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</main>
    
    <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sit\resources\views/site/home/solutions/byField/construction-and-contracting.blade.php ENDPATH**/ ?>