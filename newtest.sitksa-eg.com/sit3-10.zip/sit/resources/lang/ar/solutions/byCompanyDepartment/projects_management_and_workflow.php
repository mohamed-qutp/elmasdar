<?php
return
[
    'solutiontitle'=>'إدارة المشاريع وسير العمل',
    'solutionadvantagesbasetitle'=>'مزايا نظام إدارة المشاريع وسير العمل',
    'solutionadvantage1'=>'مراقبة كل مشروع يتم فتحه',
    'solutionadvantage2'=>'تحديد الجدول الزمني',
    'solutionadvantage3'=>'تحديد مَن المسئول عن كل مرحلة وتوزيع المهام',
    'solutionadvantage4'=>'إمكانية المقارنة بين النسب المئوية في عملية التخطيط والنسب المئوية في عملية التنفيذ لأخذ القرار الصائب',
    'solutionadvantage5'=>'إمكانية الرقابة على الموظفين وسعة الإنجازات الخاصة بهم',
    'solutionadvantage6'=>'إمكانية استخراج مستخلص شهري أو ربع سنوي',
    'solutionadvantage7'=>'مراقبة حجم إنجاز المشاريع',
    'solutionadvantage8'=>'مراقبة جودة التنفيذ',    
];