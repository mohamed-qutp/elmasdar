<?php
return
[
    'solutiontitle'=>'الحسابات العامة ',
    'solutionadvantagesbasetitle'=>'مزايا نظام إدارة الحسابات العامة',
    'solutionadvantage1'=>'دليل مالي متعدد المراحل',
    'solutionadvantage2'=>'مراكز تكلفة متفرعة',
    'solutionadvantage3'=>'حركات مالية مرنة',
    'solutionadvantage4'=>'إمكانية إنشاء أنواع أنظمة للقيود وأنواع أنظمة للحركات',
    'solutionadvantage5'=>'متابعة دقيقة لدفتر الأستاذ وميزان المراجعة',
    'solutionadvantage6'=>'ربط مباشر بين الدليل المالي ومراكز التكلفة',
    'solutionadvantage7'=>'إمكانية الربط بين النظام الأساسي ونظام آخر',
    'solutionadvantage8'=>'نظام سحابي لعدد مستخدمين غير محدود',
    'solutionadvantage9'=>'نظام تأمين عالي',
    'solutionadvantage10'=>'استيعاب حجم بيانات ضخم',
    'solutionadvantage11'=>'إمكانية إدارة أكثر من فترة مالية وأكثر من سنة مالية',    
];