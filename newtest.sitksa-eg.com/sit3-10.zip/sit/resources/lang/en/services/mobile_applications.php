<?php
return
[
    'servicetitle'=>'Mobile applications',
    'servicedescription'=>'They are software programs made specifically to run mobile operating systems, like iOS, Android, and others. These programs cover a wide range of topics and purposes and offer an interactive user interface that enables users to quickly access content or carry out specific tasks on their mobile phones.
    Planning, design, programming, and quality testing are all steps in the same process that go into creating a web site. The user experience with mobile devices, including application response and compatibility with various display and device sizes, is of particular relevance.
    ',   
    'logostitle'=>'Our Portfolio', 
];