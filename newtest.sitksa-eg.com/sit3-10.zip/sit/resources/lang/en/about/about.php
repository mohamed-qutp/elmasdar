<?php
return
[
    'abouttitle'=>'About SIT',
    'aboutdescriptiononetitle'=>'Success Stories Born From The Heart Of Source',
    'aboutdescriptionone'=>'The information technology source includes an extraordinary set of task forces, engineers, and programmers to provide innovation in all technological solutions determined to meet the client demands.',
    'aboutdescriptiontwo'=>'According to Saudi Arabia’s 2030 vision and the digital transformation revolution that invades the world, the source of information technology provides detailed software solutions to clients’ needs, delivering a vision in software and IT development.',
    'aboutdescriptionthree'=>'Since 2012, the Foundation has been providing the highest standards of quality, serving as a pioneer in the age of digitization and technological transformation, and placing client satisfaction and confidence at the top of its priorities, primarily because it is our client first.',
    'aboutdescriptionfourtitle'=>'Some Advantages Which SIT Provide :',
    'aboutdescriptionfour1'=>' Use state-of-the-art digital technology.',
    'aboutdescriptionfour2'=>'Provide an unprecedented customer support service.',
    'aboutdescriptionfour3'=>' We rely on the most powerful databases.',
    'aboutdescriptionfour4'=>' We support you in reaching the highest standards of cyber security.',
];