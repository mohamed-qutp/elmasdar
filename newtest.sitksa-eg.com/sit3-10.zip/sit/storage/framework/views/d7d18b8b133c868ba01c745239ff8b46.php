<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $__env->make('site.layouts_ar.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
    <div class="wrapper">
    <?php echo $__env->make('site.layouts_ar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutiontitle')); ?></h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">الرئيسية</a></li>
                        <li class="breadcrumb-item active"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutiontitle')); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  
    <div id="video" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <!-- Video Preview -->
                    <div class="image-container">
                        <div class="video-wrapper">
                            <a class="popup-youtube" href="https://www.youtube.com/watch?v=fLCjQJCekTs" data-effect="fadeIn">
                               
                                <span class="video-play-button">
                                    <span></span>
                                </span>
                            </a>
                        </div> <!-- end of video-wrapper -->
                    </div> <!-- end of image-container -->
                    <!-- end of video preview -->                   
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div>
  <section id="hero" class="hero bg-gray-100">
        <div class="container">
        <div class="container">
        <div class="row  justify-content-center section-heading">
                        <div class="col-lg-8 col-xl-7 text-center wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
                        <h3 class="bg-primary-after after-50px pb-3 mb-3"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationbasetitle')); ?></h3>                       
                      </div>
                    </div>
            <div class="row wow fadeInUp" data-wow-duration="0.5s" style="visibility: visible; animation-duration: 0.5s; animation-name: fadeInUp;">
            <div class="col-lg-12 col-xl-12">            
                <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationone')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/rental_of_vehicles.solutionclassificationonefeatures'));
                                          echo $str; ?></p>
                  <h4 class="h4 mb-3"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationtwo')); ?></h4>
                <p class="lead mb-3"><?php $str = htmlspecialchars_decode(trans('solutions/byField/rental_of_vehicles.solutionclassificationtwofeatures'));
                                          echo $str; ?></p>                                      
            </div>  
        </div>   

</div>
</section>
   
<?php echo $__env->make('site.layouts_ar.ask-for-quotation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
       
</main>
    
    <?php echo $__env->make('site.layouts_ar.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts_ar.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('site.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <body>
        <div class="wrapper">
        <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4"> <?php echo e(trans('solutions/byField/rental_of_vehicles.solutiontitle')); ?> </h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active"> <?php echo e(trans('solutions/byField/rental_of_vehicles.solutiontitle')); ?> </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  
    <div id="video" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <!-- Video Preview -->
                    <div class="image-container">
                        <div class="video-wrapper">
                            <a class="popup-youtube" href="https://www.youtube.com/watch?v=fLCjQJCekTs" data-effect="fadeIn">
                                
                                <span class="video-play-button">
                                    <span></span>
                                </span>
                            </a>
                        </div> <!-- end of video-wrapper -->
                    </div> <!-- end of image-container -->
                    <!-- end of video preview -->                   
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> 
    <section class="section bg-gray-100">
        <div class="container">
            <div class="row section-heading justify-content-center text-center wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="col-lg-8 col-xl-6">
                <h3 class="h1 bg-primary-after after-50px pb-3 mb-3"><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationbasetitle')); ?></h3>
                <!-- <div class="lead">Mombo is a HTML5 template based on Sass and Bootstrap 5 with modern and creative multipurpose design you can use it as a startups. -->

                </div>
            </div>
        </div>
        <div class="tab-style-4 mt-3">
            <ul class="nav nav-fill nav-tabs wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" role="tablist" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <li class="nav-item" role="presentation">
                <a href="#tab3_sec1_03" data-bs-toggle="tab" class="" aria-selected="false" role="tab" tabindex="-1">
                    <div class="tb-icon">
                        <i class="bi bi-chat"></i>
                    </div>
                    <span><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationone')); ?></span>
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a href="#tab3_sec2_03" data-bs-toggle="tab" aria-selected="false" role="tab" class="" tabindex="-1">
                    <div class="tb-icon"><i class="bi bi-tools"></i></div><span><?php echo e(trans('solutions/byField/rental_of_vehicles.solutionclassificationtwo')); ?></span>
                </a>
            </li>            
        </ul>
        <div class="tab-content wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
        <!-- start tab content -->
        <div id="tab3_sec1_03" class="tab-pane fade in" role="tabpanel">
            <div class="row align-items-center gy-4 pt-5">
                <div class="col-lg-5 pe-xl-8">
                    <!-- <div class="h2 mb-3">
                        Make smarter business decisions with data analysis
                    </div> -->
                    <p class="lead mb-5">
                    <?php $str = htmlspecialchars_decode(trans('solutions/byField/rental_of_vehicles.solutionclassificationonefeatures'));
                                          echo $str; ?>
                    </p>
                 
                </div>
            </div>
            <div class="col-lg-7 text-center">
                <img src="../../assets/img/feature/feature-7.png" title="" alt="">
            </div>
        </div>
    </div><!-- end tab content --><!-- start tab content -->
    <div id="tab3_sec2_03" class="tab-pane fade in" role="tabpanel">
        <div class="row align-items-center gy-4 pt-5 flex-row-reverse">
            <div class="col-lg-5 ps-xl-8">
                <!-- <div class="h2 mb-3">
                    Make smarter business decisions with data analysis
                </div> -->
                <p class="lead mb-5">
                <?php $str = htmlspecialchars_decode(trans('solutions/byField/rental_of_vehicles.solutionclassificationtwofeatures'));
                                          echo $str; ?>
                </p>
                <!-- <div class="media mb-5">
                    <div class="icon icon-lg border border-primary rounded bg-gray-100 dots-icon">
                        <i class="bi-laptop"></i> 
                        <span class="dots">
                            <i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i>
                        </span>
                    </div>
                    <div class="media-body ps-3">
                        <h6>Web Development</h6>
                        <p class="m-0">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.
                        </p>
                    </div>
                </div> -->
              
            </div>
            <div class="col-lg-7 text-center">
                <img src="../../assets/img/feature/feature-8.png" title="" alt="">
            </div>
        </div>
    </div><!-- end tab content -->
</div>
</div>
</div>
</section>
    
<?php echo $__env->make('site.layouts.ask-for-quotation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</main>
    
    <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sit\resources\views/site/home/solutions/byField/rental-of-vehicles.blade.php ENDPATH**/ ?>