<!DOCTYPE html>
<!-- saved from url=(0058)https://www.pxdraft.com/wrap/mombo/html/home/index-29.html -->
<html  dir="ltr" lang="en" class="dark" data-bs-theme="light">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- metas -->
    <meta name="author" content="pxdraft"><meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name="keywords" content="Crikon – Multipurpose Template"><meta name="description" content="Crikon – Multipurpose Template">
    <!-- title --><title>SIT</title>
    <!-- <link href="<?php echo e(asset('assets/images/logo-2.png')); ?>" rel="icon"> -->
    <!-- Favicon --><link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo-2.png')); ?>">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <!-- CSS Template -->
    <!-- <link href="<?php echo e(asset('assets/css/aos.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>" rel="stylesheet">    
    <link href="<?php echo e(asset('assets/css/regular.min.css')); ?>" rel="stylesheet">    
    <link href="<?php echo e(asset('assets/css/theme.css')); ?>" rel="stylesheet">    
  </head>
  <?php /**PATH C:\xampp\htdocs\sit\resources\views/site/layouts/head.blade.php ENDPATH**/ ?>