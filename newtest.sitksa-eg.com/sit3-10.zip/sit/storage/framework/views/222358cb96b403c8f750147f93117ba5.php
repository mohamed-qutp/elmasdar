</div>
<!-- script start --><!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
<!--bootstrap--><script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- headroom JS -->
<script src="<?php echo e(asset('assets/js/headroom.min.js')); ?>"></script>
<!-- swiper JS -->
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
<!-- purecounter JS -->
<script src="<?php echo e(asset('assets/js/purecounter_vanilla.js')); ?>"></script>
<!-- isotope JS -->
<script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
<!-- magnific JS -->
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- magnific JS -->
<script src="<?php echo e(asset('assets/js/highlight.min.js')); ?>"></script>
<!-- magnific JS -->
<script src="<?php echo e(asset('assets/js/typed.js')); ?>"></script>
<!-- svginjector JS -->
<script src="<?php echo e(asset('assets/js/svg-injector.min.js')); ?>"></script>
<!-- wow JS -->
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<!-- wow JS -->
<script src="<?php echo e(asset('assets/js/jquery.easypiechart.min.js')); ?>"></script>
<!-- countdown JS -->
<script src="<?php echo e(asset('assets/js/jquery.countdown.min.js')); ?>"></script>
<!-- one-page JS -->
<script src="<?php echo e(asset('assets/js/scrollIt.min.js')); ?>"></script>
<!-- working form -->
<script src="<?php echo e(asset('assets/js/form.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/theme-jquery.js')); ?>"></script>
<!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
<!-- Dark/Light JS -->
<script src="<?php echo e(asset('assets/js/color-modes.js')); ?>"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/175711/delaunay.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/gsap/1.13.2/TweenMax.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<!-- End script start -->
<script>
    //Maruf al Bashir Reza
		$(window).on('load', function() { // makes sure the whole site is loaded 
			$('#status').fadeOut(); // will first fade out the loading animation 
            $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
            $('body').delay(550).css({'overflow':'visible'});
		})
</script>
    <script>
        $(document).ready(function() {
        // $(".navbar").hover(mouseEnter, mouseLeave);
        var timer;
         $(".nav-link").hover(function() {       
           document.getElementById("blur_body").style.filter = "blur(7px)";          
           document.getElementById("blur_footer").style.filter = "blur(7px)";
           var id = $(this).attr("id"); 
           setTimeout(displayCurrentMenuItem, 100,id);         

}, function () {     
        document.getElementById("blur_body").style.filter = "blur(0px)";
        document.getElementById("blur_footer").style.filter = "blur(0px)";
        document.getElementById("services").style.filter = "blur(0px)";
        document.getElementById("solutions").style.filter = "blur(0px)";
        document.getElementById("clients").style.filter = "blur(0px)"; 
        document.getElementById("search_icon").style.filter = "blur(0px)";                    
        document.getElementById('dm').style.filter = "blur(0px)";
   
});
$("#dm").hover(function() {       
           document.getElementById("blur_body").style.filter = "blur(7px)";          
           document.getElementById("blur_footer").style.filter = "blur(7px)";
           document.getElementById("services").style.filter = "blur(7px)";
           document.getElementById("solutions").style.filter = "blur(7px)";
           document.getElementById("clients").style.filter = "blur(7px)"; 
           document.getElementById("search_icon").style.filter = "blur(7px)";                    
           document.getElementById('dm').style.filter = "blur(0px)";
               

}, function () {     
        document.getElementById("blur_body").style.filter = "blur(0px)";
        document.getElementById("blur_footer").style.filter = "blur(0px)";
        document.getElementById("services").style.filter = "blur(0px)";
        document.getElementById("solutions").style.filter = "blur(0px)";
        document.getElementById("clients").style.filter = "blur(0px)"; 
        document.getElementById("search_icon").style.filter = "blur(0px)";                    
        document.getElementById('dm').style.filter = "blur(0px)";
   
});
// search popup show
$("#search_icon").on('click', function(e) {
            e.preventDefault();
            $(".search-popup").addClass('popup');
            document.getElementById("h_blur0").style.filter = "blur(7px)"; 
            document.getElementById("blur_body").style.filter = "blur(7px)";          
            document.getElementById("blur_footer").style.filter = "blur(7px)";
        });       

        // search popup remove
        $("#searchCloseBtn, .search-popup-overlay").on('click', function() {
            $(".search-popup").removeClass('popup');
            document.getElementById("h_blur0").style.filter = "blur(0px)"; 
            document.getElementById("blur_body").style.filter = "blur(0px)";
            document.getElementById("blur_footer").style.filter = "blur(0px)";
        });

                   

function displayCurrentMenuItem(id)
{
    if(id === "services")
                {
                   // document.getElementById("services").style.display = 'block';
                    document.getElementById("solutions").style.filter = "blur(7px)";
                    document.getElementById("clients").style.filter = "blur(7px)";
                    document.getElementById("search_icon").style.filter = "blur(7px)";                    
                    document.getElementById('dm').style.filter = "blur(7px)";

                }
                else if(id === "solutions")
                {
                    document.getElementById("services").style.filter = "blur(7px)";
                    //document.getElementById("solutions").style.display = 'block';
                    document.getElementById("clients").style.filter = "blur(7px)";
                    document.getElementById("search_icon").style.filter = "blur(7px)";                    
                    document.getElementById('dm').style.filter = "blur(7px)";
                }
                else if(id === "clients")
                {
                    document.getElementById("services").style.filter = "blur(7px)";
                    document.getElementById("solutions").style.filter = "blur(7px)";
                   // document.getElementById("clients").style.display = 'block'; 
                    document.getElementById("search_icon").style.filter = "blur(7px)";                    
                    document.getElementById('dm').style.filter = "blur(7px)";
                }
                else if(id === "search_icon")
                {
                    document.getElementById("services").style.filter = "blur(7px)";
                    document.getElementById("solutions").style.filter = "blur(7px)";
                    document.getElementById("clients").style.display = 'blur(7px)'; 
                    document.getElementById("search_icon").style.filter = "blur(0px)";                    
                    document.getElementById('dm').style.filter = "blur(7px)";
                }
                else if(id === "demos")
                {
                    document.getElementById("home").style.display = 'none';
                    document.getElementById("pages").style.display = 'none';
                    document.getElementById("blog").style.display = 'none';     
                    document.getElementById("search_icon").style.display = 'none';                                
                    document.getElementById('dm').style.visibility = 'hidden';
                }  
                $('.dropdown-item').hover(function(){
                    document.getElementById("blur_body").style.filter = "blur(3px)";
                    document.getElementById("blur_footer").style.filter = "blur(3px)";
                    var dropDownId = $(this).attr("id");
                    if(id === "services")
                    {
                     document.getElementById("services").style.filter = "blur(0px)";
                     document.getElementById("solutions").style.filter = "blur(7px)";
                     document.getElementById("clients").style.filter = "blur(7px)";
                     document.getElementById("search_icon").style.filter = "blur(7px)";                    
                     document.getElementById('dm').style.filter = "blur(7px)";
                        if(dropDownId === "home_link1")
                        {
                            document.getElementById("home_img").src="/assets/images/1.jpg";
                        }
                        else if(dropDownId === "home_link2")
                        {
                            document.getElementById("home_img").src="/assets/images/2.jpg";
                        }
                        else if(dropDownId === "home_link3")
                        {
                            document.getElementById("home_img").src="/assets/images/3.jpg"; 
                        }
                    }
                    else if(id === "solutions")
                    {
                     document.getElementById("services").style.filter = "blur(7px)";
                     document.getElementById("solutions").style.filter = "blur(0px)";
                     document.getElementById("clients").style.filter = "blur(7px)";
                     document.getElementById("search_icon").style.filter = "blur(7px)";                    
                     document.getElementById('dm').style.filter = "blur(7px)";
                        if(dropDownId === "page_link1")
                        {
                            document.getElementById("page_img").src="/assets/images/1.jpg";
                        }
                        else if(dropDownId === "page_link2")
                        {
                            document.getElementById("page_img").src="/assets/images/2.jpg";
                        }
                        else if(dropDownId === "page_link3")
                        {
                            document.getElementById("page_img").src="/assets/images/3.jpg";
                        }
                    }
                    else if(id === "clients")
                    {
                     document.getElementById("services").style.filter = "blur(7px)";
                     document.getElementById("solutions").style.filter = "blur(7px)";
                     document.getElementById("clients").style.filter = "blur(0px)";
                     document.getElementById("search_icon").style.filter = "blur(7px)";                    
                     document.getElementById('dm').style.filter = "blur(7px)";
                        if(dropDownId === "blog_link1")
                        {
                            document.getElementById("blog_img").src="/assets/images/1.jpg";
                        }
                        else if(dropDownId === "blog_link2")
                        {
                            document.getElementById("blog_img").src="/assets/images/2.jpg";
                        }
                        else if(dropDownId === "blog_link3")
                        {
                            document.getElementById("blog_img").src="/assets/images/3.jpg";
                        }
                    }
                    else if(id === "elements")
                    {
                        document.getElementById("home").style.display = 'none';
                        document.getElementById("pages").style.display = 'none';
                        document.getElementById("blog").style.display = 'none';   
                        document.getElementById("search_icon").style.display = 'none';                                
                        document.getElementById('dm').style.visibility = 'hidden';
                        if(dropDownId === "elem_link1")
                        {
                            document.getElementById("elem_img").src="/assets/images/1.jpg";
                        }
                        else if(dropDownId === "elem_link2")
                        {
                            document.getElementById("elem_img").src="/assets/images/2.jpg";

                        }
                        else if(dropDownId === "elem_link3")
                        {
                            document.getElementById("elem_img").src="/assets/images/3.jpg";
                        }
                    }
                    else if(id === "demos")
                    {
                        document.getElementById("home").style.display = 'none';
                        document.getElementById("pages").style.display = 'none';
                        document.getElementById("blog").style.display = 'none';  
                        document.getElementById("search_icon").style.display = 'none';                                         
                        document.getElementById('dm').style.visibility = 'hidden';
                        if(dropDownId === "demo_link1")
                        {
                            document.getElementById("demo_img").src="/assets/images/1.jpg";
                        }
                        else if(dropDownId === "demo_link2")
                        {
                            document.getElementById("demo_img").src="/assets/images/2.jpg";
                        }
                        else if(dropDownId === "demo_link3")
                        {
                            document.getElementById("demo_img").src="/assets/images/3.jpg";
                        }
                    }  
                },function () {
        document.getElementById("blur_body").style.filter = "blur(0px)";
        document.getElementById("blur_footer").style.filter = "blur(0px)";
        document.getElementById("services").style.filter = 'blur(0px)';
        document.getElementById("solutions").style.filter = 'blur(0px)';
        document.getElementById("clients").style.filter = 'blur(0px)';     
        document.getElementById("search_icon").style.filter = 'blur(0px)';   
        document.getElementById('dm').style.filter = 'blur(0px)';
});
}     
});
function showHide(elm) {
if (elm == "Customer Support") {
//display textbox
  document.getElementById('message').style.display = "block";
} else {
//hide textbox
  document.getElementById('message').style.display = "none";
}

}

$(window).on('scroll', function(){
var s = $(window).scrollTop(),
d = $(document).height(),
c = $(window).height();
 
var scrollPercent = (s / (d - c)) * 100;
//document.getElementById('scrollId').innerHTML = scrollPercent;
console.log(scrollPercent); //Displaying scroll percentage in console
 
if(scrollPercent < 5){
document.getElementById("header_img").src = "<?php echo e(asset('assets/images/bg-banner-1.jpg')); ?>";
//document.getElementById('img2').style.display = "none";
}
else if(scrollPercent > 5 && scrollPercent < 10){
    document.getElementById("header_img").src= "https://i1.wp.com/cdn.catawiki.net/assets/marketing/uploads-files/45485-8bdcc8479f93d5a247ab844321b8b9d5e53c49a9-story_inline_image.jpg";
//document.getElementById('img2').style.display = "block";
}
else if(scrollPercent > 10 && scrollPercent < 20){
    document.getElementById("header_img").src ='https://s-media-cache-ak0.pinimg.com/originals/e1/7a/03/e17a0385726db90de1854177d4af2b4f.jpg';
}
 
})
//popup code
const modal =  document.getElementById("modal");
//const openModal = document.querySelector(".open-button");
const closeModal = document.querySelector(".close-button");
const modalBtn = document.querySelectorAll('.open-button');
        modalBtn.forEach(function(e) {
        e.addEventListener('click', openModal);
})
function openModal()
{
    modal.style.display = "block";
    document.getElementById("blur_body").style.filter = "blur(8px)";          
    document.getElementById("blur_footer").style.filter = "blur(7px)";
    document.getElementById("services").style.filter = "blur(7px)";
    document.getElementById("solutions").style.filter = "blur(7px)";
    document.getElementById("clients").style.filter = "blur(7px)"; 
    document.getElementById("search_icon").style.filter = "blur(7px)";                    
    document.getElementById('dm').style.filter = "blur(7px)";    
}
closeModal.addEventListener("click", () => {
  modal.style.display = "none";
  document.getElementById("blur_body").style.filter = "blur(0px)";          
  document.getElementById("blur_footer").style.filter = "blur(0px)";
  document.getElementById("services").style.filter = "blur(0px)";
  document.getElementById("solutions").style.filter = "blur(0px)";
  document.getElementById("clients").style.filter = "blur(0px)"; 
  document.getElementById("search_icon").style.filter = "blur(0px)";                    
  document.getElementById('dm').style.filter = "blur(0px)";
});
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
    document.getElementById("blur_body").style.filter = "blur(0px)";          
    document.getElementById("blur_footer").style.filter = "blur(0px)";
    document.getElementById("services").style.filter = "blur(0px)";
    document.getElementById("solutions").style.filter = "blur(0px)";
    document.getElementById("clients").style.filter = "blur(0px)"; 
    document.getElementById("search_icon").style.filter = "blur(0px)";                    
    document.getElementById('dm').style.filter = "blur(0px)";
  }
} 

//logo slider

$('.logos-slider').slick({
slidesToShow: 4,
slidesToScroll: 1,
autoplay: true,
autoplaySpeed: 1500,
arrows: false,
dots: false,
pauseOnHover: false,
responsive: [{
breakpoint: 768,
settings: {
slidesToShow: 3
}
}, {
breakpoint: 520,
settings: {
slidesToShow: 2
}
}]
});
// const TWO_PI = Math.PI * 2;

// var images = [],
//     imageIndex = 0;

// var image,
//     imageWidth = 1850,
//     imageHeight = 485;

// var vertices = [],
//     indices = [],
//     fragments = [];

// var container = document.getElementById('container');

// var clickPosition = [imageWidth * 0.5, imageHeight * 0.5];

// window.onload = function() {
//     // TweenMax.set(container, {perspective:500});

//     // images from reddit/r/wallpapers
//     // var urls = [
//     //         'https://s3-us-west-2.amazonaws.com/s.cdpn.io/175711/crayon.jpg'
          
//     //     ],
//         // image = new Image();
//         //console.log(image);
//         //loaded = 0;
//     // very quick and dirty hack to load and display the first image asap
//     // images[0] = image = new Image();
//     //     image.onload = function() {
//     //         image = document.getElementById("header_img").src;
//     //         console.log("img1:"+image);
//     // //         if (++loaded === 1) {
//                 // imagesLoaded();
//         //         for (var i = 1; i < 4; i++) {
//         //             images[i] = image = new Image();

//         //             image.src = urls[i];
//         //         }
//         //     }
//         // };
//         // image.src = urls[0];
// };
// // $('#header_img').click(function(){
// //     imagesLoaded();    
// // }); 
// $(window).bind('mousewheel', function(event) {
// if (event.originalEvent.wheelDelta >= 0) {
//     document.getElementById("header_img").style.display="block";
// }
// else {
//    //console.log('Scroll down');
//    imagesLoaded();
// }
// });

// function imagesLoaded() {
//     placeImage(false);
//     triangulate();
//     shatter();
   
// }

// function placeImage(transitionIn) {
//     image = new Image();
//     image.src = document.getElementById("header_img").src;
//     console.log("img1:"+image);
//     // if (++imageIndex === images.length) imageIndex = 0;

//     // image.addEventListener('click', imageClickHandler);
//     // container.appendChild(image);

//     if (transitionIn !== false) {
//          TweenMax.fromTo(image, 0.75, {y:-1000}, {y:0, ease:Back.easeOut});
//     }
// }

// function imageClickHandler(event) {
//     var box = image.getBoundingClientRect(),
//         top = box.top,
//         left = box.left;

//     clickPosition[0] = event.clientX - left;
//     clickPosition[1] = event.clientY - top;

//     triangulate();
//    // shatter();
// }

// function triangulate() {
//     var rings = [
//             {r:50, c:12},
//             {r:150, c:12},
//             {r:300, c:12},
//             {r:1200, c:12} // very large in case of corner clicks
//         ],
//         x,
//         y,
//         centerX = clickPosition[0],
//         centerY = clickPosition[1];

//     vertices.push([centerX, centerY]);

//     rings.forEach(function(ring) {
//         var radius = ring.r,
//             count = ring.c,
//             variance = radius * 0.25;

//         for (var i = 0; i < count; i++) {
//             x = Math.cos((i / count) * TWO_PI) * radius + centerX + randomRange(-variance, variance);
//             y = Math.sin((i / count) * TWO_PI) * radius + centerY + randomRange(-variance, variance);
//             vertices.push([x, y]);
//         }
//     });

//     vertices.forEach(function(v) {
//         v[0] = clamp(v[0], 0, imageWidth);
//         v[1] = clamp(v[1], 0, imageHeight);
//     });
    

//     indices = Delaunay.triangulate(vertices);
//     console.log(indices);
//     document.getElementById("header_img").style.display="none";
// }

// function shatter() {
//     var p0, p1, p2,
//         fragment;

//     var tl0 = new TimelineMax({onComplete:shatterCompleteHandler});

//     for (var i = 0; i < indices.length; i += 3) {
//         p0 = vertices[indices[i + 0]];
//         p1 = vertices[indices[i + 1]];
//         p2 = vertices[indices[i + 2]];

//         fragment = new Fragment(p0, p1, p2);

//         var dx = fragment.centroid[0] - clickPosition[0],
//             dy = fragment.centroid[1] - clickPosition[1],
//             d = Math.sqrt(dx * dx + dy * dy),
//             rx = 30 * sign(dy),
//             ry = 90 * -sign(dx),
//             delay = d * 0.019* randomRange(0.9, 1.1);
//         fragment.canvas.style.zIndex = Math.floor(d).toString();

//         var tl1 = new TimelineMax();


//         tl1.to(fragment.canvas, 1, {
//             z:-500,
//             rotationX:rx,
//             rotationY:ry,
//             ease:Cubic.easeIn
//         });
//         tl1.to(fragment.canvas, 0.4,{alpha:0}, 0.6);

//         tl0.insert(tl1, delay);

//         fragments.push(fragment);
//         container.appendChild(fragment.canvas);
//     }
//     document.getElementById("header_img").style.display="none";
//     // container.removeChild(image);
//     // image.removeEventListener('click', imageClickHandler);
// }

// function shatterCompleteHandler() {
//     // add pooling?
//     fragments.forEach(function(f) {
//         container.removeChild(f.canvas);
//     });
//     fragments.length = 0;
//     vertices.length = 0;
//     indices.length = 0;

//     placeImage();
// }

// //////////////
// // MATH UTILS
// //////////////

// function randomRange(min, max) {
//     return min + (max - min) * Math.random();
// }

// function clamp(x, min, max) {
//     return x < min ? min : (x > max ? max : x);
// }

// function sign(x) {
//     return x < 0 ? -1 : 1;
// }

// //////////////
// // FRAGMENT
// //////////////

// Fragment = function(v0, v1, v2) {
//     this.v0 = v0;
//     this.v1 = v1;
//     this.v2 = v2;

//     this.computeBoundingBox();
//     this.computeCentroid();
//     this.createCanvas();
//     this.clip();
// };
// Fragment.prototype = {
//     computeBoundingBox:function() {
//         var xMin = Math.min(this.v0[0], this.v1[0], this.v2[0]),
//             xMax = Math.max(this.v0[0], this.v1[0], this.v2[0]),
//             yMin = Math.min(this.v0[1], this.v1[1], this.v2[1]),
//             yMax = Math.max(this.v0[1], this.v1[1], this.v2[1]);           

//         this.box ={
//             x:xMin,
//             y:yMin,
//             w:xMax - xMin,
//             h:yMax - yMin
//         };
//     },
//     computeCentroid:function() {
//         var x = (this.v0[0] + this.v1[0] + this.v2[0]) / 3,
//             y = (this.v0[1] + this.v1[1] + this.v2[1]) / 3;

//         this.centroid = [x, y];
//     },
//     createCanvas:function() {
//         this.canvas = document.createElement('canvas');
//         this.canvas.width = this.box.w;
//         this.canvas.height = this.box.h;
//         this.canvas.style.width = this.box.w + 'px';
//         this.canvas.style.height = this.box.h + 'px';
//         this.canvas.style.left = this.box.x + 'px';
//         this.canvas.style.top = this.box.y + 'px';
//         this.ctx = this.canvas.getContext('2d');
//     },
//     clip:function() {
//         this.ctx.translate(-this.box.x, -this.box.y);
//         this.ctx.beginPath();
//         this.ctx.moveTo(this.v0[0], this.v0[1]);
//         this.ctx.lineTo(this.v1[0], this.v1[1]);
//         this.ctx.lineTo(this.v2[0], this.v2[1]);
//         this.ctx.closePath();
//         this.ctx.clip();
//         this.ctx.drawImage(image, 0, 0);
//     }
// };
</script>

</body>
</html><?php /**PATH D:\Desktop\sit\resources\views/site/layouts/js.blade.php ENDPATH**/ ?>