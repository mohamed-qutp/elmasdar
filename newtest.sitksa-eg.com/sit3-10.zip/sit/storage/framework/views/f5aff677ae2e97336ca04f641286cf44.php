<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $__env->make('site.layouts_ar.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
    <div class="wrapper">
    <?php echo $__env->make('site.layouts_ar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4">احصل على عرض سعر</h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">الرئيسية</a></li>
                        <li class="breadcrumb-item active">احصل على عرض سعر</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  

      
       
        <section class="section bg-gray-100">
        <div class="container">
             <div class="row justify-content-center">  
             <div class="col-lg-6 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInRight;">
                <div class="card p-4 " style="background:#ffffff;border:0 !important;">
                    <div class="card-body bg-body p-lg-4">
                    <h5 data-aos="fade-up"  class="bg-primary-after pb-3 mb-3 text-center">احصل على عرض سعر</h5>    
                        <div class="pb-6">
                       
                        <!-- <h5 class="m-0">You Can Mail Us</h5> -->
                        </div>
                        <form action="<?php echo e(route('sendEmail')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <?php if(session()->has('Add')): ?>
                        <div class="alert alert-success  text-center alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('Add')); ?></strong>

                        </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                            <div class="row gy-4">
                                <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input id="fname" type="text" name="fname" placeholder="Rachel Roth" class="form-control">
                                        <!-- <span class="invalid-feedback"></span> -->
                                         <label class="form-label rd-input-label" for="contact-name">الاسم الأول</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input id="lname" type="text" name="lname" placeholder="Rachel Roth" class="form-control">
                                        <!-- <span class="invalid-feedback"></span> -->
                                         <label class="form-label rd-input-label" for="contact-name">الاسم الأخير</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                            <input id="email" type="email" name="email" placeholder="name@example.com" class="form-control">
                                            <!-- <span class="invalid-feedback"></span>  -->
                                            <label class="form-label rd-input-label" for="contact-email">البريد الالكترونى</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="phone" name="phone" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">رقم الموبايل</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="role" name="role" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">الوظيفة</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="company" name="company" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">الشركة</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    <div>                                           
                                            <select class="form-control">
                                                <option>اختر الدولة</option>
                                                <option></option>
                                                </select>
                                        </div>
                                    </div> 
                                    <div class="col-sm-6">
                                    <label class="form-label rd-input-label">مهتم ب ؟</label>
                                        <div>
                                        <input type="checkbox" id="financials" name="financials" value="Financials">
                                             <label class="form-label rd-input-label" for="financials">الحسابات العامة</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                             <input type="checkbox" id="inventory" name="inventory" value="Inventory">
                                             <label class="form-label rd-input-label" for="inventory">إدارة المخزون</label><br/>
                                             <input type="checkbox" id="procurement" name="procurement" value="Procurement">
                                             <label class="form-label rd-input-label" for="procurement">فواتير شراء</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                             
                                             <input type="checkbox" id="crm" name="crm" value="CRM">
                                             <label class="form-label rd-input-label" for="crm">أنظمة CRM</label><br/>
                                             <input type="checkbox" id="manufacturing" name="manufacturing" value="Manufacturing">
                                             <label class="form-label rd-input-label" for="manufacturing">مجال الإنتاج الصناعي</label>&nbsp;&nbsp;&nbsp;
                                             <input type="checkbox" id="projects" name="projects" value="Projects">
                                             <label class="form-label rd-input-label" for="projects">إدارة المشاريع</label><br/>
                                             <input type="checkbox" id="hr" name="hr" value="HR,Payroll">
                                             <label class="form-label rd-input-label" for="HR,Payroll">إدارة الموارد البشرية</label>
                                        </div>
                                    </div>                         
                                   
                                    <div class="col-12">
                                    <div class="card-footer d-flex">
                                <button type="submit" class="btn submit-btn me-3">ارسال</button> 
                                <!-- <button class="btn btn-primary-light">Cancel</button> -->
                            </div>
                                        <div class="snackbars" id="form-output-global">

                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>    
             <!-- <div class="col-lg-1"></div> -->
             <!-- <div class="col-lg-1"></div> -->
          <div class="col-lg-6 wow fadeInLeft" data-wow-duration=".4s" data-wow-delay="0.05s" style="visibility: visible; animation-duration: 0.4s; animation-delay: 0.05s; animation-name: fadeInLeft;">
              <div class="hover-top bg-cover bg-centerp-2 shadow rounded-3 ms-xl-12 overflow-hidden position-relative" style="background-image: url(<?php echo e(asset('assets/images/ai-1.svg')); ?>);">
              <div class="mask opacity-6 bg-dark"></div>
              <div class="position-relative p-4 pt-8" style="height:315px;">
                 <!-- <p class="mb-2 text-white">02 Mar 2019</p> -->
                 <h5 class="text-white pt-10" style="text-align:center;"><a href="#" class="text-white stretched-link" >Call To Action</a></h5>
                <!-- <p class="text-white text-opacity-65 m-0"></p> -->
                <div class="media border-style top light pt-3 mt-4">
                    <!-- <div class="avatar-sm">
                        <img class="avatar-img rounded-circle" src="../../assets/img/avatar/avatar-1.jpg" title="" alt="">
                    </div> -->
                    <!-- <div class="media-body ps-3 align-self-center"><span class="text-white">Rachel Roth</span></div> -->
                </div>
              </div>
             </div>
         </div>
             
           
                 
                 
         </div>
                                        </div>
                                    </section>
</main>
    
    <?php echo $__env->make('site.layouts_ar.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts_ar.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('site.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <body>
        <div class="wrapper">
        <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <main id="blur_body">
        <section class="section effect-section bg-cover bg-center bg-no-repeat page-heading" style="background-image: url(/assets/images/request-a-Demo.jpg);">
        <div class="bg-black opacity-6 mask"></div>
        <div class="container position-relative wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white h1 mb-4">Demo Request</h2>
                    <ol class="breadcrumb breadcrumb-light justify-content-center">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Demo Request</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>  

      
       
        <section class="section bg-gray-100">
        <div class="container">
             <div class="row justify-content-center">  
             <div class="col-lg-6 wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInLeft;">
                <div class="card border-0 p-4" style="background:#ffffff;border:0 !important;">
                    <div class="card-body bg-body p-lg-4">
                    <h5 data-aos="fade-up"  class="bg-primary-after pb-3 mb-3 text-center">Ask for a Quotation</h5> 
                        <div class="pb-6">
                        <!-- <h5 class="m-0">You Can Mail Us</h5> -->
                        </div>
                        <form action="<?php echo e(route('sendEmail')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <?php if(session()->has('Add')): ?>
                        <div class="alert alert-success  text-center alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('Add')); ?></strong>

                        </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                            <div class="row gy-4">
                                <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input id="fname" type="text" name="fname" placeholder="Rachel Roth" class="form-control">
                                        <!-- <span class="invalid-feedback"></span> -->
                                         <label class="form-label rd-input-label" for="contact-name">First Name</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input id="lname" type="text" name="lname" placeholder="Rachel Roth" class="form-control">
                                        <!-- <span class="invalid-feedback"></span> -->
                                         <label class="form-label rd-input-label" for="contact-name">Last Name</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                            <input id="email" type="email" name="email" placeholder="name@example.com" class="form-control">
                                            <!-- <span class="invalid-feedback"></span>  -->
                                            <label class="form-label rd-input-label" for="contact-email">Email Address</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="phone" name="phone" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">Phone Number</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="role" name="role" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">Your Role</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-floating">
                                             <input type="tel" id="company" name="company" class="form-control" placeholder="+01 888 888 6666" id="phone">
                                             <label class="form-label rd-input-label" for="contact-phone">Your Company</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                    <div>                                           
                                            <select class="form-control">
                                                <option>Select a country</option>
                                                <option></option>
                                                </select>
                                        </div>
                                    </div>      
                                    <div class="col-sm-6">
                                    <label class="form-label rd-input-label">Interested In?</label>
                                        <div>
                                        <input type="checkbox" id="financials" name="financials" value="Financials">
                                             <label class="form-label rd-input-label" for="financials">Financials</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                             <input type="checkbox" id="inventory" name="inventory" value="Inventory">
                                             <label class="form-label rd-input-label" for="inventory">Inventory</label><br/>
                                             <input type="checkbox" id="procurement" name="procurement" value="Procurement">
                                             <label class="form-label rd-input-label" for="procurement">Procurement</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                             <input type="checkbox" id="crm" name="crm" value="CRM">
                                             <label class="form-label rd-input-label" for="crm">CRM</label><br/>
                                             <input type="checkbox" id="manufacturing" name="manufacturing" value="Manufacturing">
                                             <label class="form-label rd-input-label" for="manufacturing">Manufacturing</label>&nbsp;&nbsp;&nbsp;
                                             <input type="checkbox" id="projects" name="projects" value="Projects">
                                             <label class="form-label rd-input-label" for="projects">Projects</label><br/>
                                             <input type="checkbox" id="hr" name="hr" value="HR,Payroll">
                                             <label class="form-label rd-input-label" for="HR,Payroll">HR & Payroll</label>
                                        </div>
                                    </div>           
                                   
                                    <div class="col-12">
                                    <div class="card-footer d-flex">
                                <button type="submit" class="btn me-3 submit-btn">Submit</button> 
                                <!-- <button class="btn btn-primary-light">Cancel</button> -->
                            </div>
                                        <div class="snackbars" id="form-output-global">

                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>    
             <!-- <div class="col-lg-1"></div> -->
             <!-- <div class="col-lg-1"></div> -->
          <div class="col-lg-6 wow fadeInRight" data-wow-duration=".4s" data-wow-delay="0.05s" style="visibility: visible; animation-duration: 0.4s; animation-delay: 0.05s; animation-name: fadeInRight;">
              <div class="hover-top bg-cover bg-centerp-2 shadow rounded-3 ms-xl-12 overflow-hidden position-relative" style="background-image: url(<?php echo e(asset('assets/images/ai-1.svg')); ?>);">
              <div class="mask opacity-6 bg-dark"></div>
              <div class="position-relative p-4 pt-8" style="height:315px;">
                 <!-- <p class="mb-2 text-white">02 Mar 2019</p> -->
                 <h5 class="text-white pt-10" style="text-align:center;"><a href="#" class="text-white stretched-link" >Call To Action</a></h5>
                <!-- <p class="text-white text-opacity-65 m-0"></p> -->
                <div class="media border-style top light pt-3 mt-4">
                    <!-- <div class="avatar-sm">
                        <img class="avatar-img rounded-circle" src="../../assets/img/avatar/avatar-1.jpg" title="" alt="">
                    </div> -->
                    <!-- <div class="media-body ps-3 align-self-center"><span class="text-white">Rachel Roth</span></div> -->
                </div>
              </div>
             </div>
         </div>
             
           
                 
                 
         </div>
                                        </div>
                                    </section>
</main>
    
    <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\sit\resources\views/site/home/request-demo.blade.php ENDPATH**/ ?>