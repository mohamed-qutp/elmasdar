<section class="section bg-gray-100 header-blur-light"  style="padding-top: 4.6875rem !important;
    padding-bottom: 4.6875rem !important;">
        <div class="container">
            <div class="row justify-content-center text-center">
                 <div class="col-lg-4 my-3 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.1s" style="visibility: visible; animation-duration: 0.5s; animation-delay: 0.1s; animation-name: fadeInUp;
   n                 padding: 1em;">
                    <a href="<?php echo e(route('demo-request')); ?>" class="btn btn-outline-white ask-for-quotation ms-2">احصل على عرض سعر</a>
  
                  </div>
            </div>
</div>
</section><?php /**PATH /home/sitksaeg/public_html/newtest.sitksa-eg.com/resources/views/site/layouts_ar/ask-for-quotation.blade.php ENDPATH**/ ?>