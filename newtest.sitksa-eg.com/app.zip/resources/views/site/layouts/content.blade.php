@include('site.layouts.head')
<body id="blur_body">
@include('site.layouts.header')
@include('site.layouts.footer')
@include('site.layouts.js')