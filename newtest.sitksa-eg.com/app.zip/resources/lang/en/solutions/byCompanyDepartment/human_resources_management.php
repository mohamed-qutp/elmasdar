<?php
return
[
    'solutiontitle'=>'Human resources management ',
    'solutionadvantagesbasetitle'=>'Advantages of the human resources management ERP system:',
    'solutionadvantage1'=>'Informing staff about multiple departments, businesses, and roles',
    'solutionadvantage2'=>'Tying personnel to storage, donations, special offers, and prizes',
    'solutionadvantage3'=>'Potential staff division into the several business units',
    'solutionadvantage4'=>'The potential for document control for employees contracts, visas, and addresses',
    'solutionadvantage5'=>'Letters of alert for papers related to contracts before they are completed',
    'solutionadvantage6'=>'Linking users to a certain branch and allowing for changes when a staff member transfers across branches',
    'solutionadvantage7'=>'Transferability of all employee data following contract change',
    'solutionadvantage8'=>'The potential implementation of the staff evaluation system',
    'solutionadvantage9'=>'Presentation of all personnel records',     
];