<?php
return
[
    'solutiontitle'=>'Tasks Management System',
    'solutionadvantagesbasetitle'=>'Advantages Of The Tasks Management ERP System:',
    'solutionadvantage1'=>'Prepare lists of the projects',
    'solutionadvantage2'=>'Distribution of the tasks to staff',
    'solutionadvantage3'=>'Official task case tracking',
    'solutionadvantage4'=>'Possibility of commenting on existing tasks',
    'solutionadvantage5'=>'Determine extent to which the staff member has completed the current tasks',
    'solutionadvantage6'=>'Comparison of the planning process with the results provided',
    'solutionadvantage7'=>'Identification of KPIs for each employee',   
];