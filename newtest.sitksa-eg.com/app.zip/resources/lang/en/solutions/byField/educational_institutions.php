<?php
return
[
    'solutiontitle'=>'Educational Institutions',
    'solutionclassificationbasetitle'=>'The ERP system in the field of educational institutions is divided into:',
    
    'solutionclassificationonefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Universities’ data.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Colleges’ data.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Subjects’ data.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Clients’ data.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Students’ data.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Operations.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Sales.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Student registration.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Payment of expenses.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span> Information inquires.    
    ',    
];