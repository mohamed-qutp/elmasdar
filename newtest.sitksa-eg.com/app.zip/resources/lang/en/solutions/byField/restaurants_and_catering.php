<?php
return
[
    'solutiontitle'=>'Restaurants and Catering',
    'solutionclassificationbasetitle'=>'The ERP Catering and restaurants System is divided into:',
    'solutionclassificationone'=>'Coding Checklist',
    'solutionclassificationonefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>A branch coding.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	Category coding.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	Quantity and price coding.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	Coding of session classifications.    
    ',
    'solutionclassificationtwo'=>'Total billing report',    
    'solutionclassificationthree'=>'Warehouse movement',
    'solutionclassificationthreefeatures'=>'<span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>Permission to add receivables.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	Permission to add a store.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	Transfer permission.<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>Store movement report.    
    ',    
];