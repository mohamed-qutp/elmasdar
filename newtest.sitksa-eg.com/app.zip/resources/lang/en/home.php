<?php
return 
[
    'ourservices'=>'Our Services',
    'erpsystem'=>'ERP System',
    'possystem'=>'POS System',
    'webdevelopment'=>'Web Development',
    'mobileapplication'=>'Mobile Application',
    'webapplication'=>'Web Application',
    'cybersecurity'=>'Cyber Security',
    'digitalmarketing'=>'Digital Marketing',
    'customersupport'=>'Technical Support',
    'ourclients'=>'Our Clients',
];