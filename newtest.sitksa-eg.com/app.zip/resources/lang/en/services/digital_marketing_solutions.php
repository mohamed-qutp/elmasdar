<?php
return
[
    'servicetitle'=>'Digital Marketing Solutions',
    'servicedescription'=>'Online marketing tactics and resources are employed to promote goods, services, or brands. Digital marketing relies on communicating with customers, both existing and potential, through electronic channels and platforms. By producing value-added content that makes the public loyal to you and your company, we at the source of information technology offer our clients intelligent solutions and improve their presence on local and international commercial markets. This allows us to increase sales using digital technology and electronic means.',
];