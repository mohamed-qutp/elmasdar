<?php
return
[
    'servicetitle'=>'Web Applications',
    'servicedescription'=>'Although it is online-based software, it is a separate sort that users can access without downloading and installing additional software. These programs can be found on distant servers and offer a user interface that is interactive and accessible as well as information sharing and service delivery.
    These programs play a significant role in users daily lives since they provide services for a wide range of sectors, including social networking, online banking, online shopping, business administration, and educational content.
    ',
    'logostitle'=>'Our Portfolio',
];