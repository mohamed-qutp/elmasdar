<?php
return
[
    'servicetitle'=>'Web Development',
    'servicedescription'=>'It is the process of creating and programming e-mail and developing its components, creating an end product on the web that offers a user-friendly experience and a user-friendly version of various devices that are easy to surf. The development of web sites covers many different aspects, such as graphic design, front-end programming, background programming, database management, site safety, and other technical and functional aspects.',
    'findoutaboutourservicestitle'=>'Find out about our services',
    'findoutaboutourservices1'=>'Design codes using different programming languages.',
    'findoutaboutourservices2'=>'Modernization and development of the websites of companies or enterprises.',
    'findoutaboutourservices3'=>'Designing the form of the outside site, including colors, images, sections, etc.',
    'findoutaboutourservices4'=>'Discovering and resolving the problems facing the sites.',
    'findoutaboutourservices5'=>'Fixing the technical malfunctions and finding out why they have occurred in order to avoid them in the future.',
    
];