<?php
return
[
    'solutiontitle'=>'إدارة سلسلة التوريد',
    'solutionadvantagesbasetitle'=>'مزايا نظام إدارة سلسلة التوريد',
    'solutionadvantage1'=>'إنشاء عدد غير منتهى من المخازن سواء رئيسية أو فرعية',
    'solutionadvantage2'=>'ربط كل مخزن بفرع معين',
    'solutionadvantage3'=>'صلاحيات متفرعة للمستخدمين أصحاب المخازن',
    'solutionadvantage4'=>'إدارة تفصيلية لنشاط مناديب المبيعات',
    'solutionadvantage5'=>'إمكانية البيع داخل وخارج المكتب',
    'solutionadvantage6'=>'إنشاء فواتير لحظية عن العملاء',
    'solutionadvantage7'=>'إمكانية استخدام طلبات الشراء عن طريق السحابة الإلكترونية',
    'solutionadvantage8'=>'إمكانية إدارة سماحية الموردين من أرصدة الأصناف',
    'solutionadvantage9'=>'إمكانية التكامل مع أي أنظمة لدى الموردين',
    'solutionadvantage10'=>'إمكانية الرقابة الدقيقة لحساب كل مورد',   
];