<?php
return
[
    'solutiontitle'=>'إدارة المهام الوظيفية',
    'solutionadvantagesbasetitle'=>'مزايا نظام إدارة المهام الوظيفية',
    'solutionadvantage1'=>'إنشاء قوائم للمشاريع',
    'solutionadvantage2'=>'توزيع المهام على الموظفين',
    'solutionadvantage3'=>'تتبع حالات المهام من قِبل المسؤولين',
    'solutionadvantage4'=>'إمكانية التعليق على المهام القائمة ',
    'solutionadvantage5'=>'تحديد مدى إنجاز الموظف للمهام الحالية',
    'solutionadvantage6'=>'مقارنة عملية التخطيط بالنتائج المقدمة',
    'solutionadvantage7'=>'تحديد الـ KPIs لكل موظف  ',   
];