<?php
return
[    
    'solutiontitle'=>'مجال الإنشاءات ',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال الإنشاءات ينقسم إلى:',
    'solutionclassificationone'=>'• شاشات ملف البيانات الأساسية',
    'solutionclassificationonefeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	شاشة أنواع المستندات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	شاشة تعريف الإجراءات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	إعدادات النظام
    ',
    'solutionclassificationtwo'=>'• شاشات العمليات اليومية',
    'solutionclassificationtwofeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>الوارد <br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	الصادر<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	شاشة الدخول على صندوق الوارد <br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	شاشة صندوق الوارد<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	الأرشيف<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	الإحالة
    ',
    'solutionclassificationthree'=>'• شاشة الاستعلامات والتقارير',
    'solutionclassificationthreefeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	طباعة الباركود<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i></span>	متابعة المعاملات 
    ',    
];