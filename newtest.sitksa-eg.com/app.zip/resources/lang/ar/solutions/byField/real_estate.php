<?php
return
[
    'solutiontitle'=>'مجال العقارات والمقاولات ',
    'solutionclassificationbasetitle'=>'نظام ERP في مجال العقارات والمقاولات ينقسم إلى:',
    'solutionclassificationone'=>'شاشات البيانات الأساسية',
    'solutionclassificationonefeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	بيانات العقارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	الوحدات العقارية<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	ملاك العقارات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	بيانات المستأجرون<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	عناصر نماذج العقود<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	أنواع المصروفات<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	أنواع العقود<br/>
    ',
    'solutionclassificationtwo'=>'	شاشات الحركات والعمليات',
    'solutionclassificationtwofeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	عقد الإيجار<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	مصروفات الصيانة<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	مراجعة وتفعيل عقود الإيجار<br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	فك تفعيل العقود
    ',
    'solutionclassificationthree'=>'	شاشات التقارير والاستعلامات',
    'solutionclassificationthreefeatures'=>' <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	كشف حساب مستأجر <br/>
    <span class="elementor-icon-list-icon">
    <i aria-hidden="true" class="far fa-check-circle"></i> </span>	أقساط الإيجار
    ',   
];